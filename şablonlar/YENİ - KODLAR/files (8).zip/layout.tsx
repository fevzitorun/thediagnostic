'use client'

// ─── SCANBOOK SHARED LAYOUT COMPONENTS ───────────────────────────────────────
// components/layout.tsx
//
// Export list:
//   <Header />          — sticky nav, used on every page
//   <Footer />          — full footer with columns, used on every page
//   <Breadcrumb />      — page breadcrumb trail
//
// Usage:
//   import { Header, Footer, Breadcrumb } from '@/components/layout'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useState } from 'react'

// ─── DESIGN TOKENS (keep in sync with globals.css) ───────────────────────────

export const T = {
  teal:       '#00C9A7',
  tealDark:   '#00a888',
  tealLight:  '#e6faf7',
  black:      '#111111',
  text:       '#222222',
  muted:      '#666666',
  subtle:     '#999999',
  border:     '#ebebeb',
  bg:         '#f8f8f8',
} as const

// ─── NAV LINKS ────────────────────────────────────────────────────────────────
// Enes: menü değişirse sadece buraya ekle

const NAV_LINKS = [
  { label: 'Services',      href: '/services' },
  { label: 'About',         href: '/about' },
  { label: 'How it works',  href: '/how-it-works' },
  { label: 'Find a Centre', href: '/centres' },
  { label: 'For Clinics',   href: '/partners' },
  { label: 'Blog',          href: '/blog' },
  { label: 'For Business',  href: '/for-business' },
] as const

// ─── FOOTER COLUMNS ──────────────────────────────────────────────────────────

const FOOTER_COLS = [
  {
    title: 'Scans',
    links: [
      { label: 'Private MRI Scan',     href: '/services/mri-scan' },
      { label: 'Private CT Scan',      href: '/services/ct-scan' },
      { label: 'Ultrasound Scan',      href: '/services/ultrasound' },
      { label: 'Private X-Ray',        href: '/services/x-ray' },
      { label: 'Baby Scan',            href: '/services/baby-scan' },
      { label: 'Full Body MRI',        href: '/services/full-body-mri' },
      { label: 'Open MRI',             href: '/services/open-mri' },
    ],
  },
  {
    title: 'Body Parts',
    links: [
      { label: 'Knee MRI',             href: '/body-parts/knee-mri' },
      { label: 'Brain MRI',            href: '/body-parts/brain-mri' },
      { label: 'Lumbar Spine MRI',     href: '/body-parts/lumbar-spine-mri' },
      { label: 'Shoulder MRI',         href: '/body-parts/shoulder-mri' },
      { label: 'Hip MRI',              href: '/body-parts/hip-mri' },
      { label: 'Abdominal Ultrasound', href: '/body-parts/abdominal-ultrasound' },
      { label: 'CT Chest',             href: '/body-parts/ct-chest' },
    ],
  },
  {
    title: 'Locations',
    links: [
      { label: 'MRI Scan London',      href: '/centres/london' },
      { label: 'MRI Scan Manchester',  href: '/centres/manchester' },
      { label: 'MRI Scan Birmingham',  href: '/centres/birmingham' },
      { label: 'MRI Scan Bristol',     href: '/centres/bristol' },
      { label: 'MRI Scan Edinburgh',   href: '/centres/edinburgh' },
      { label: 'Find a Centre',        href: '/centres' },
    ],
  },
  {
    title: 'Company',
    links: [
      { label: 'About ScanBook',       href: '/about' },
      { label: 'How it works',         href: '/how-it-works' },
      { label: 'For Clinics',          href: '/partners' },
      { label: 'For Business',         href: '/for-business' },
      { label: 'Blog / Health Hub',    href: '/blog' },
      { label: 'Contact us',           href: '/contact' },
    ],
  },
] as const

// ─── HEADER ──────────────────────────────────────────────────────────────────

export function Header() {
  const pathname = usePathname()
  const [mobileOpen, setMobileOpen] = useState(false)

  return (
    <>
      <style>{`
        .sb-nav-link { padding: 7px 13px; font-size: 13px; color: ${T.muted}; text-decoration: none; border-radius: 7px; transition: all .15s; white-space: nowrap; font-family: inherit; }
        .sb-nav-link:hover { color: ${T.black}; background: ${T.bg}; }
        .sb-nav-link.active { color: ${T.black}; font-weight: 500; }
        .sb-btn-signin { padding: 7px 16px; border: 1.5px solid ${T.border}; border-radius: 7px; background: #fff; font-size: 13px; cursor: pointer; color: ${T.text}; font-family: inherit; transition: all .15s; }
        .sb-btn-signin:hover { border-color: #bbb; }
        .sb-btn-book { padding: 8px 18px; border: none; border-radius: 7px; background: ${T.teal}; color: #fff; font-size: 13px; font-weight: 600; cursor: pointer; font-family: inherit; transition: opacity .15s; }
        .sb-btn-book:hover { opacity: .88; }
      `}</style>

      <nav style={{
        height: 60,
        padding: '0 48px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        borderBottom: `1px solid ${T.border}`,
        position: 'sticky',
        top: 0,
        background: '#fff',
        zIndex: 200,
      }}>

        {/* Logo */}
        <Link href="/" style={{ display: 'flex', alignItems: 'center', textDecoration: 'none', letterSpacing: -0.5 }}>
          <span style={{ fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", fontSize: 20, fontWeight: 700, color: T.black }}>Scan</span>
          <span style={{ fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", fontSize: 20, fontWeight: 700, color: T.teal }}>Book</span>
        </Link>

        {/* Nav links — desktop */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          {NAV_LINKS.map(link => (
            <Link
              key={link.href}
              href={link.href}
              className={`sb-nav-link${pathname?.startsWith(link.href) ? ' active' : ''}`}
            >
              {link.label}
            </Link>
          ))}
        </div>

        {/* Right actions */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <button className="sb-btn-signin">Sign In</button>
          <Link href="/search">
            <button className="sb-btn-book">Book a Scan</button>
          </Link>
        </div>

      </nav>
    </>
  )
}

// ─── BREADCRUMB ───────────────────────────────────────────────────────────────

interface BreadcrumbItem {
  label: string
  href?: string
}

export function Breadcrumb({ items }: { items: BreadcrumbItem[] }) {
  return (
    <>
      <style>{`
        .sb-bc a { color: ${T.subtle}; text-decoration: none; transition: color .15s; }
        .sb-bc a:hover { color: ${T.black}; }
      `}</style>
      <div className="sb-bc" style={{ padding: '10px 48px', fontSize: 12, color: '#bbb', borderBottom: `1px solid #f5f5f5` }}>
        {items.map((item, i) => (
          <span key={i}>
            {i > 0 && <span style={{ margin: '0 6px' }}>/</span>}
            {item.href
              ? <Link href={item.href}>{item.label}</Link>
              : <span style={{ color: '#444' }}>{item.label}</span>
            }
          </span>
        ))}
      </div>
    </>
  )
}

// ─── FOOTER ───────────────────────────────────────────────────────────────────

export function Footer() {
  return (
    <footer style={{ background: '#111', color: '#fff' }}>

      {/* Main columns */}
      <div style={{ maxWidth: 1180, margin: '0 auto', padding: '56px 48px 48px', display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr 1fr 1fr', gap: 48 }}>

        {/* Brand column */}
        <div>
          <div style={{ display: 'flex', alignItems: 'center', marginBottom: 16, letterSpacing: -0.5 }}>
            <span style={{ fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", fontSize: 20, fontWeight: 700, color: '#fff' }}>Scan</span>
            <span style={{ fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", fontSize: 20, fontWeight: 700, color: T.teal }}>Book</span>
          </div>
          <p style={{ fontSize: 13, color: 'rgba(255,255,255,.38)', lineHeight: 1.7, marginBottom: 20, maxWidth: 200 }}>
            The UK's private imaging marketplace. Book a scan at 600+ CQC-registered centres.
          </p>

          {/* Trust badges */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {[
              { icon: '✓', text: 'CQC Partner Network' },
              { icon: '✓', text: 'No GP referral needed' },
              { icon: '✓', text: 'Stripe secure payments' },
            ].map((b, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 12, color: 'rgba(255,255,255,.35)' }}>
                <span style={{ color: T.teal, fontWeight: 700, fontSize: 11 }}>{b.icon}</span>
                {b.text}
              </div>
            ))}
          </div>

          {/* Trustpilot */}
          <div style={{ marginTop: 20, padding: '12px 14px', background: 'rgba(255,255,255,.05)', borderRadius: 10, border: '1px solid rgba(255,255,255,.08)' }}>
            <div style={{ fontSize: 11, color: 'rgba(255,255,255,.4)', marginBottom: 4 }}>Rated on Trustpilot</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ color: '#00b67a', fontSize: 14, letterSpacing: 1 }}>★★★★★</span>
              <span style={{ fontSize: 13, color: '#fff', fontWeight: 500 }}>4.9</span>
              <span style={{ fontSize: 11, color: 'rgba(255,255,255,.3)' }}>2,400 reviews</span>
            </div>
          </div>
        </div>

        {/* Link columns */}
        {FOOTER_COLS.map(col => (
          <div key={col.title}>
            <div style={{ fontSize: 11, fontWeight: 600, color: 'rgba(255,255,255,.5)', letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 16 }}>
              {col.title}
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
              {col.links.map(link => (
                <Link
                  key={link.href}
                  href={link.href}
                  style={{ fontSize: 13, color: 'rgba(255,255,255,.4)', textDecoration: 'none', transition: 'color .15s', lineHeight: 1.4 }}
                  onMouseEnter={e => (e.currentTarget.style.color = 'rgba(255,255,255,.85)')}
                  onMouseLeave={e => (e.currentTarget.style.color = 'rgba(255,255,255,.4)')}
                >
                  {link.label}
                </Link>
              ))}
            </div>
          </div>
        ))}

      </div>

      {/* Bottom bar */}
      <div style={{ borderTop: '1px solid rgba(255,255,255,.06)', padding: '18px 48px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
        <span style={{ fontSize: 11, color: 'rgba(255,255,255,.2)' }}>
          © 2025 The Connective UK Ltd &nbsp;·&nbsp; CQC Partner Network &nbsp;·&nbsp; Registered in England and Wales
        </span>
        <div style={{ display: 'flex', gap: 24 }}>
          {[
            { label: 'Privacy Policy', href: '/privacy-policy' },
            { label: 'Terms & Conditions', href: '/terms-and-conditions' },
            { label: 'Cookie Policy', href: '/cookie-policy' },
            { label: 'Accessibility', href: '/accessibility' },
          ].map(l => (
            <Link
              key={l.href}
              href={l.href}
              style={{ fontSize: 11, color: 'rgba(255,255,255,.25)', textDecoration: 'none', transition: 'color .15s' }}
              onMouseEnter={e => (e.currentTarget.style.color = 'rgba(255,255,255,.6)')}
              onMouseLeave={e => (e.currentTarget.style.color = 'rgba(255,255,255,.25)')}
            >
              {l.label}
            </Link>
          ))}
        </div>
      </div>

    </footer>
  )
}
