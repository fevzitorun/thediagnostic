'use client'

// ─── SCANBOOK HOMEPAGE ────────────────────────────────────────────────────────
// app/page.tsx
//
// Sections:
//   1. Hero — headline + inline search bar
//   2. Trust bar — key numbers
//   3. Scan types — 6 service cards
//   4. How it works — 3 steps
//   5. Popular body parts — grid
//   6. Featured clinics — 3 cards
//   7. Why ScanBook — 4 pillars
//   8. Reviews — Trustpilot strip
//   9. CTA — dark band
//
// TODO Enes:
//   - Replace FEATURED_CLINICS mock with prisma.clinic.findMany({ where: { featured: true }, take: 3 })
//   - Wire up search bar to /search?type=...&location=...
//   - Add real review data from Trustpilot API or static seed

import Link from 'next/link'
import { useState } from 'react'
import { Header, Footer } from '@/components/layout'

// ─── CONSTANTS ────────────────────────────────────────────────────────────────

const SCAN_TYPES = [
  { slug: 'mri-scan',    label: 'MRI Scan',       sub: 'From £275',  icon: '🧲', desc: 'Detailed soft tissue and joint imaging. No radiation.' },
  { slug: 'ct-scan',     label: 'CT Scan',         sub: 'From £185',  icon: '🔬', desc: 'Fast cross-sectional imaging. Results in 24 hours.' },
  { slug: 'ultrasound',  label: 'Ultrasound',      sub: 'From £99',   icon: '🔊', desc: 'Safe, real-time imaging. No radiation, no referral.' },
  { slug: 'x-ray',       label: 'X-Ray',           sub: 'From £75',   icon: '🦴', desc: 'Fast and affordable. In and out in 30 minutes.' },
  { slug: 'baby-scan',   label: 'Baby Scan',       sub: 'From £89',   icon: '👶', desc: 'Early pregnancy, dating, gender and 4D scans.' },
  { slug: 'full-body-mri', label: 'Full Body MRI', sub: 'From £1,450',icon: '🫀', desc: 'Comprehensive whole-body screening. No radiation.' },
]

const BODY_PARTS = [
  { name: 'Knee MRI',         href: '/body-parts/knee-mri',         icon: '🦵' },
  { name: 'Brain MRI',        href: '/body-parts/brain-mri',        icon: '🧠' },
  { name: 'Lumbar Spine MRI', href: '/body-parts/lumbar-spine-mri', icon: '🦴' },
  { name: 'Shoulder MRI',     href: '/body-parts/shoulder-mri',     icon: '💪' },
  { name: 'CT Chest',         href: '/body-parts/ct-chest',         icon: '🫁' },
  { name: 'Abdominal US',     href: '/body-parts/abdominal-ultrasound', icon: '⚕️' },
  { name: 'Hip MRI',          href: '/body-parts/hip-mri',          icon: '🦴' },
  { name: 'Prostate MRI',     href: '/body-parts/prostate-mri',     icon: '🔬' },
]

const HOW_IT_WORKS = [
  {
    num: '01',
    title: 'Choose your scan',
    body: 'Select your scan type and body part. Filter by location, date, price and scanner quality. No GP referral needed.',
    icon: '🔍',
  },
  {
    num: '02',
    title: 'Book & pay securely',
    body: 'Pick a date at your nearest CQC-registered centre. Pay securely via Stripe. Instant email confirmation.',
    icon: '📅',
  },
  {
    num: '03',
    title: 'Get your report',
    body: 'Attend your appointment. A UK consultant radiologist reports your scan within 24–48 hours to your secure portal.',
    icon: '📋',
  },
]

const WHY_SCANBOOK = [
  { icon: '⚡', title: 'No waiting lists', body: 'Skip NHS waiting times. Appointments often available within 48 hours at centres near you.' },
  { icon: '🏥', title: '600+ CQC centres', body: 'Every partner centre is CQC registered. Radiologists are UK-qualified consultants.' },
  { icon: '💷', title: 'Transparent pricing', body: 'Fixed prices, no hidden fees. Price includes your scan, images, and radiologist\'s report.' },
  { icon: '📄', title: 'Report in 24–48 hrs', body: 'Full written report delivered to your secure portal. Share directly with your GP or consultant.' },
]

// TODO Enes: replace with DB fetch
const FEATURED_CLINICS = [
  {
    id: 'medicana-winchester',
    name: 'Medicana Winchester',
    city: 'Winchester, Hampshire',
    rating: 4.9,
    reviewCount: 312,
    tesla: '3T',
    priceFrom: 275,
    nextSlot: 'Tomorrow',
    cqc: 'Outstanding',
    tags: ['Free parking', '24h report', 'Baby scan suite'],
  },
  {
    id: 'unirad-london',
    name: 'Unirad Imaging',
    city: 'London W1G',
    rating: 4.7,
    reviewCount: 189,
    tesla: '1.5T',
    priceFrom: 195,
    nextSlot: 'Today',
    cqc: 'Good',
    tags: ['MRI specialist', 'Step-free access', 'Near tube'],
  },
  {
    id: 'harley-street-imaging',
    name: 'Harley Street Imaging',
    city: 'London W1G',
    rating: 4.9,
    reviewCount: 421,
    tesla: '3T',
    priceFrom: 299,
    nextSlot: 'Tomorrow',
    cqc: 'Outstanding',
    tags: ['3T scanner', 'Same day available', 'All insurers'],
  },
]

const REVIEWS = [
  { author: 'Sarah M.', scan: 'MRI Knee', rating: 5, text: 'Booked online on a Monday morning and was scanned by Wednesday. Report was back in 24 hours. Completely seamless.', initials: 'SM' },
  { author: 'James P.', scan: 'CT Chest', rating: 5, text: 'Incredible service. The Harley Street centre was spotless and the radiographer was very reassuring. Report was excellent.', initials: 'JP' },
  { author: 'Emma R.', scan: '4D Baby Scan', rating: 5, text: 'We were made to feel so welcome. The 4D images were beautiful. Worth every penny for the peace of mind.', initials: 'ER' },
]

// ─── HERO SEARCH BAR ─────────────────────────────────────────────────────────

function HeroSearch() {
  const [scanType, setScanType] = useState('')
  const [location, setLocation] = useState('')

  const handleSearch = () => {
    const params = new URLSearchParams()
    if (scanType) params.set('type', scanType)
    if (location) params.set('location', location)
    window.location.href = `/search?${params.toString()}`
  }

  return (
    <div style={{
      display: 'flex',
      border: '1.5px solid #111',
      borderRadius: 14,
      overflow: 'hidden',
      background: '#fff',
      boxShadow: '0 4px 32px rgba(0,0,0,.1)',
      maxWidth: 720,
    }}>
      {/* Scan type */}
      <div style={{ flex: 1.2, padding: '14px 18px', borderRight: '1px solid #ebebeb', cursor: 'pointer' }}>
        <div style={{ fontSize: 10, fontWeight: 700, color: '#bbb', letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 4 }}>Scan type</div>
        <select
          value={scanType}
          onChange={e => setScanType(e.target.value)}
          style={{ width: '100%', border: 'none', outline: 'none', fontSize: 14, fontWeight: scanType ? 500 : 400, color: scanType ? '#111' : '#bbb', fontFamily: 'inherit', background: 'transparent', cursor: 'pointer', appearance: 'none' }}
        >
          <option value="">Select a scan…</option>
          {SCAN_TYPES.map(s => <option key={s.slug} value={s.slug}>{s.label}</option>)}
        </select>
      </div>

      {/* Location */}
      <div style={{ flex: 1, padding: '14px 18px', borderRight: '1px solid #ebebeb' }}>
        <div style={{ fontSize: 10, fontWeight: 700, color: '#bbb', letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 4 }}>Location</div>
        <input
          value={location}
          onChange={e => setLocation(e.target.value)}
          placeholder="City or postcode"
          onKeyDown={e => e.key === 'Enter' && handleSearch()}
          style={{ width: '100%', border: 'none', outline: 'none', fontSize: 14, color: '#111', fontFamily: 'inherit', background: 'transparent', '::placeholder': { color: '#bbb' } } as React.CSSProperties}
        />
      </div>

      {/* CTA */}
      <button
        onClick={handleSearch}
        style={{ padding: '0 28px', background: '#111', color: '#fff', border: 'none', fontSize: 14, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit', display: 'flex', alignItems: 'center', gap: 8, transition: 'background .15s', whiteSpace: 'nowrap' }}
        onMouseEnter={e => (e.currentTarget.style.background = '#00C9A7')}
        onMouseLeave={e => (e.currentTarget.style.background = '#111')}
      >
        Find a scan →
      </button>
    </div>
  )
}

// ─── SCAN TYPE CARD ───────────────────────────────────────────────────────────

function ScanCard({ scan }: { scan: typeof SCAN_TYPES[0] }) {
  return (
    <Link
      href={`/services/${scan.slug}`}
      style={{ border: '1px solid #ebebeb', borderRadius: 16, padding: '22px 20px', background: '#fff', cursor: 'pointer', textDecoration: 'none', display: 'flex', flexDirection: 'column', gap: 10, transition: 'all .18s' }}
      onMouseEnter={e => { const el = e.currentTarget; el.style.borderColor = '#00C9A7'; el.style.boxShadow = '0 6px 24px rgba(0,201,167,.1)'; el.style.transform = 'translateY(-2px)' }}
      onMouseLeave={e => { const el = e.currentTarget; el.style.borderColor = '#ebebeb'; el.style.boxShadow = 'none'; el.style.transform = '' }}
    >
      <div style={{ width: 44, height: 44, borderRadius: 12, background: '#f8f8f8', display: 'grid', placeItems: 'center', fontSize: 22, marginBottom: 2 }}>{scan.icon}</div>
      <div>
        <div style={{ fontSize: 15, fontWeight: 600, color: '#111', marginBottom: 2 }}>{scan.label}</div>
        <div style={{ fontSize: 12, color: '#00a888', fontWeight: 500 }}>{scan.sub}</div>
      </div>
      <div style={{ fontSize: 13, color: '#888', lineHeight: 1.55 }}>{scan.desc}</div>
      <div style={{ fontSize: 12, color: '#bbb', marginTop: 'auto' }}>View details →</div>
    </Link>
  )
}

// ─── CLINIC CARD ─────────────────────────────────────────────────────────────

function ClinicCard({ clinic }: { clinic: typeof FEATURED_CLINICS[0] }) {
  const is3T = clinic.tesla === '3T'

  return (
    <Link
      href={`/centres/${clinic.id}`}
      style={{ border: '1px solid #ebebeb', borderRadius: 16, padding: '20px 20px 18px', background: '#fff', cursor: 'pointer', textDecoration: 'none', display: 'flex', flexDirection: 'column', gap: 0, transition: 'all .18s' }}
      onMouseEnter={e => { const el = e.currentTarget; el.style.borderColor = '#ccc'; el.style.boxShadow = '0 6px 24px rgba(0,0,0,.07)'; el.style.transform = 'translateY(-2px)' }}
      onMouseLeave={e => { const el = e.currentTarget; el.style.borderColor = '#ebebeb'; el.style.boxShadow = 'none'; el.style.transform = '' }}
    >
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
        <div>
          <div style={{ fontSize: 15, fontWeight: 600, color: '#111', marginBottom: 2 }}>{clinic.name}</div>
          <div style={{ fontSize: 12, color: '#888' }}>{clinic.city}</div>
        </div>
        <span style={{ fontSize: 10, fontWeight: 700, padding: '3px 9px', borderRadius: 6, background: is3T ? '#f3e8ff' : '#f1f5f9', color: is3T ? '#7c3aed' : '#475569', border: `1px solid ${is3T ? '#ddd6fe' : '#e2e8f0'}`, whiteSpace: 'nowrap', letterSpacing: 0.3 }}>
          {clinic.tesla}
        </span>
      </div>

      {/* Meta */}
      <div style={{ display: 'flex', gap: 12, fontSize: 12, color: '#888', marginBottom: 12, flexWrap: 'wrap' }}>
        <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <span style={{ color: '#f59e0b' }}>★</span>
          <span style={{ color: '#111', fontWeight: 500 }}>{clinic.rating}</span>
          <span>({clinic.reviewCount})</span>
        </span>
        <span>·</span>
        <span style={{ color: clinic.cqc === 'Outstanding' ? '#00a888' : '#666' }}>CQC {clinic.cqc}</span>
        <span>·</span>
        <span style={{ color: clinic.nextSlot === 'Today' ? '#00a888' : '#666', fontWeight: clinic.nextSlot === 'Today' ? 500 : 400 }}>
          Next: {clinic.nextSlot}
        </span>
      </div>

      {/* Tags */}
      <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap', marginBottom: 16 }}>
        {clinic.tags.map(tag => (
          <span key={tag} style={{ fontSize: 11, padding: '3px 9px', borderRadius: 20, background: '#f8f8f8', color: '#666', border: '1px solid #ebebeb' }}>
            {tag}
          </span>
        ))}
      </div>

      {/* Price + CTA */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 'auto', paddingTop: 14, borderTop: '1px solid #f5f5f5' }}>
        <div>
          <span style={{ fontSize: 22, fontWeight: 600, color: '#111', fontFamily: "'Instrument Serif', serif", letterSpacing: -0.5 }}>£{clinic.priceFrom}</span>
          <span style={{ fontSize: 11, color: '#bbb', marginLeft: 4 }}>from</span>
        </div>
        <span style={{ fontSize: 13, color: '#00a888', fontWeight: 500 }}>View centre →</span>
      </div>
    </Link>
  )
}

// ─── PAGE ─────────────────────────────────────────────────────────────────────

export default function HomePage() {
  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'DM Sans', sans-serif; background: #fff; color: #222; -webkit-font-smoothing: antialiased; }
      `}</style>

      <Header />

      {/* ── 1. HERO ── */}
      <section style={{ maxWidth: 1180, margin: '0 auto', padding: '80px 48px 72px' }}>
        <div style={{ maxWidth: 760 }}>

          {/* Eyebrow */}
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '6px 12px', background: '#e6faf7', borderRadius: 20, marginBottom: 24 }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#00C9A7', display: 'block' }} />
            <span style={{ fontSize: 12, fontWeight: 500, color: '#00a888' }}>No GP referral needed · 600+ CQC centres</span>
          </div>

          <h1 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 60, lineHeight: 1.07, letterSpacing: -2, color: '#111', marginBottom: 20 }}>
            Private scans, booked<br />
            <em style={{ fontStyle: 'italic', color: '#00C9A7' }}>online in minutes.</em>
          </h1>

          <p style={{ fontSize: 18, color: '#666', lineHeight: 1.75, marginBottom: 36, maxWidth: 560 }}>
            Find and book private MRI, CT, ultrasound and X-Ray scans at accredited centres across the UK. Results in 24–48 hours.
          </p>

          <HeroSearch />

          {/* Quick links */}
          <div style={{ display: 'flex', gap: 8, marginTop: 16, flexWrap: 'wrap' }}>
            <span style={{ fontSize: 12, color: '#bbb' }}>Popular:</span>
            {['MRI Scan', 'CT Scan', 'Baby Scan', 'Knee MRI', 'Back MRI'].map(q => (
              <Link
                key={q}
                href={`/search?q=${encodeURIComponent(q)}`}
                style={{ fontSize: 12, padding: '4px 10px', borderRadius: 20, border: '1px solid #e8e8e8', color: '#666', textDecoration: 'none', transition: 'all .15s' }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = '#00C9A7'; e.currentTarget.style.color = '#00a888' }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = '#e8e8e8'; e.currentTarget.style.color = '#666' }}
              >
                {q}
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── 2. TRUST BAR ── */}
      <section style={{ background: '#f8f8f8', borderTop: '1px solid #ebebeb', borderBottom: '1px solid #ebebeb' }}>
        <div style={{ maxWidth: 1180, margin: '0 auto', padding: '0 48px', display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)' }}>
          {[
            { n: '600+',    l: 'CQC-registered centres' },
            { n: '£75',     l: 'Scans from' },
            { n: '24–48h',  l: 'Radiologist report' },
            { n: '4.9★',   l: 'Trustpilot rating' },
            { n: '0',       l: 'GP referral needed' },
          ].map((item, i) => (
            <div key={i} style={{ padding: '22px 16px', textAlign: 'center', borderRight: i < 4 ? '1px solid #ebebeb' : 'none' }}>
              <div style={{ fontFamily: "'Instrument Serif', serif", fontSize: 28, color: '#111', letterSpacing: -0.5, marginBottom: 4 }}>{item.n}</div>
              <div style={{ fontSize: 12, color: '#999' }}>{item.l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── 3. SCAN TYPES ── */}
      <section style={{ maxWidth: 1180, margin: '0 auto', padding: '72px 48px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 36 }}>
          <div>
            <div style={{ fontSize: 10, letterSpacing: 3, color: '#bbb', fontWeight: 500, marginBottom: 12, textTransform: 'uppercase' }}>Our services</div>
            <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 38, letterSpacing: -1, color: '#111' }}>
              What scan do you need?
            </h2>
          </div>
          <Link href="/services" style={{ fontSize: 13, color: '#888', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 4, transition: 'color .15s', flexShrink: 0 }}
            onMouseEnter={e => (e.currentTarget.style.color = '#111')}
            onMouseLeave={e => (e.currentTarget.style.color = '#888')}
          >
            View all services →
          </Link>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
          {SCAN_TYPES.map(scan => <ScanCard key={scan.slug} scan={scan} />)}
        </div>
      </section>

      {/* ── 4. HOW IT WORKS ── */}
      <section style={{ background: '#111', padding: '72px 48px' }}>
        <div style={{ maxWidth: 1180, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 52 }}>
            <div style={{ fontSize: 10, letterSpacing: 3, color: 'rgba(255,255,255,.3)', fontWeight: 500, marginBottom: 12, textTransform: 'uppercase' }}>Simple process</div>
            <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 38, letterSpacing: -1, color: '#fff' }}>
              Booked in <em style={{ fontStyle: 'italic', color: '#00C9A7' }}>three steps.</em>
            </h2>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 32 }}>
            {HOW_IT_WORKS.map((step, i) => (
              <div key={i} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <span style={{ fontFamily: "'Instrument Serif', serif", fontSize: 48, color: 'rgba(255,255,255,.1)', letterSpacing: -2, lineHeight: 1 }}>{step.num}</span>
                  <div style={{ width: 44, height: 44, borderRadius: 12, background: 'rgba(255,255,255,.06)', display: 'grid', placeItems: 'center', fontSize: 22 }}>{step.icon}</div>
                </div>
                <div style={{ fontSize: 18, fontWeight: 500, color: '#fff', lineHeight: 1.3 }}>{step.title}</div>
                <div style={{ fontSize: 14, color: 'rgba(255,255,255,.45)', lineHeight: 1.75 }}>{step.body}</div>
                {i < HOW_IT_WORKS.length - 1 && (
                  <div style={{ position: 'absolute' }} />
                )}
              </div>
            ))}
          </div>

          <div style={{ textAlign: 'center', marginTop: 48 }}>
            <Link href="/how-it-works" style={{ fontSize: 13, color: 'rgba(255,255,255,.45)', textDecoration: 'none', borderBottom: '1px solid rgba(255,255,255,.15)', paddingBottom: 2 }}>
              Learn more about how ScanBook works →
            </Link>
          </div>
        </div>
      </section>

      {/* ── 5. POPULAR BODY PARTS ── */}
      <section style={{ maxWidth: 1180, margin: '0 auto', padding: '72px 48px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 32 }}>
          <div>
            <div style={{ fontSize: 10, letterSpacing: 3, color: '#bbb', fontWeight: 500, marginBottom: 12, textTransform: 'uppercase' }}>Browse by area</div>
            <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 38, letterSpacing: -1, color: '#111' }}>Popular scans by body part</h2>
          </div>
          <Link href="/body-parts" style={{ fontSize: 13, color: '#888', textDecoration: 'none', flexShrink: 0 }}
            onMouseEnter={e => (e.currentTarget.style.color = '#111')}
            onMouseLeave={e => (e.currentTarget.style.color = '#888')}
          >
            View all →
          </Link>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 9 }}>
          {BODY_PARTS.map(bp => (
            <Link
              key={bp.href}
              href={bp.href}
              style={{ padding: '14px 16px', border: '1px solid #ebebeb', borderRadius: 12, background: '#fff', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 10, fontSize: 13, fontWeight: 500, color: '#111', transition: 'all .15s' }}
              onMouseEnter={e => { const el = e.currentTarget; el.style.borderColor = '#00C9A7'; el.style.background = '#e6faf7'; el.style.color = '#00a888' }}
              onMouseLeave={e => { const el = e.currentTarget; el.style.borderColor = '#ebebeb'; el.style.background = '#fff'; el.style.color = '#111' }}
            >
              <span style={{ fontSize: 20 }}>{bp.icon}</span>
              {bp.name}
            </Link>
          ))}
        </div>
      </section>

      {/* ── 6. FEATURED CLINICS ── */}
      <section style={{ background: '#f8f8f8', padding: '72px 48px', borderTop: '1px solid #ebebeb' }}>
        <div style={{ maxWidth: 1180, margin: '0 auto' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 32 }}>
            <div>
              <div style={{ fontSize: 10, letterSpacing: 3, color: '#bbb', fontWeight: 500, marginBottom: 12, textTransform: 'uppercase' }}>Top rated centres</div>
              <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 38, letterSpacing: -1, color: '#111' }}>Featured imaging centres</h2>
            </div>
            <Link href="/centres" style={{ fontSize: 13, color: '#888', textDecoration: 'none', flexShrink: 0 }}
              onMouseEnter={e => (e.currentTarget.style.color = '#111')}
              onMouseLeave={e => (e.currentTarget.style.color = '#888')}
            >
              Find a centre near you →
            </Link>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
            {FEATURED_CLINICS.map(clinic => <ClinicCard key={clinic.id} clinic={clinic} />)}
          </div>
        </div>
      </section>

      {/* ── 7. WHY SCANBOOK ── */}
      <section style={{ maxWidth: 1180, margin: '0 auto', padding: '72px 48px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 72, alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: 10, letterSpacing: 3, color: '#bbb', fontWeight: 500, marginBottom: 12, textTransform: 'uppercase' }}>Why ScanBook</div>
            <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 38, letterSpacing: -1, color: '#111', marginBottom: 20, lineHeight: 1.15 }}>
              Private imaging,<br /><em style={{ fontStyle: 'italic', color: '#00C9A7' }}>made simple.</em>
            </h2>
            <p style={{ fontSize: 15, color: '#666', lineHeight: 1.8, marginBottom: 32 }}>
              ScanBook connects patients directly with accredited private imaging centres — no referrals, no delays, no hidden fees. From booking to report, we've made private scanning as straightforward as it should be.
            </p>
            <Link
              href="/how-it-works"
              style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '12px 22px', background: '#111', color: '#fff', borderRadius: 9, fontSize: 14, fontWeight: 500, textDecoration: 'none', transition: 'background .15s' }}
              onMouseEnter={e => (e.currentTarget.style.background = '#00C9A7')}
              onMouseLeave={e => (e.currentTarget.style.background = '#111')}
            >
              How it works →
            </Link>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            {WHY_SCANBOOK.map((item, i) => (
              <div key={i} style={{ padding: 24, border: '1px solid #ebebeb', borderRadius: 16, background: '#fff' }}>
                <div style={{ fontSize: 26, marginBottom: 14 }}>{item.icon}</div>
                <div style={{ fontSize: 15, fontWeight: 600, color: '#111', marginBottom: 8 }}>{item.title}</div>
                <div style={{ fontSize: 13, color: '#888', lineHeight: 1.65 }}>{item.body}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── 8. REVIEWS ── */}
      <section style={{ background: '#f8f8f8', padding: '72px 48px', borderTop: '1px solid #ebebeb' }}>
        <div style={{ maxWidth: 1180, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 40 }}>
            <div style={{ fontSize: 10, letterSpacing: 3, color: '#bbb', fontWeight: 500, marginBottom: 12, textTransform: 'uppercase' }}>Patient reviews</div>
            <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 38, letterSpacing: -1, color: '#111', marginBottom: 12 }}>
              Trusted by thousands of patients
            </h2>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, justifyContent: 'center' }}>
              <span style={{ color: '#00b67a', fontSize: 18, letterSpacing: 2 }}>★★★★★</span>
              <span style={{ fontSize: 15, fontWeight: 600, color: '#111' }}>4.9</span>
              <span style={{ fontSize: 13, color: '#888' }}>Excellent · 2,400 reviews on Trustpilot</span>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
            {REVIEWS.map((r, i) => (
              <div key={i} style={{ background: '#fff', border: '1px solid #ebebeb', borderRadius: 16, padding: 24 }}>
                <div style={{ color: '#f59e0b', fontSize: 13, letterSpacing: 2, marginBottom: 14 }}>{'★'.repeat(r.rating)}</div>
                <p style={{ fontSize: 14, color: '#444', lineHeight: 1.75, marginBottom: 20 }}>"{r.text}"</p>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div style={{ width: 34, height: 34, borderRadius: '50%', background: '#111', color: '#fff', display: 'grid', placeItems: 'center', fontSize: 12, fontWeight: 600, flexShrink: 0 }}>{r.initials}</div>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 600, color: '#111' }}>{r.author}</div>
                    <div style={{ fontSize: 11, color: '#00a888', marginTop: 1 }}>{r.scan}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── 9. CTA ── */}
      <section style={{ background: '#111', padding: '80px 48px', textAlign: 'center' }}>
        <div style={{ maxWidth: 600, margin: '0 auto' }}>
          <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 44, color: '#fff', marginBottom: 14, letterSpacing: -1.2, lineHeight: 1.1 }}>
            Ready to book your scan<br /><em style={{ fontStyle: 'italic', color: '#00C9A7' }}>today?</em>
          </h2>
          <p style={{ fontSize: 15, color: 'rgba(255,255,255,.4)', marginBottom: 36, lineHeight: 1.7 }}>
            No GP referral needed. 600+ accredited centres. Radiologist's report within 48 hours.
          </p>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link
              href="/search"
              style={{ padding: '14px 32px', border: 'none', borderRadius: 10, background: '#00C9A7', color: '#fff', fontSize: 15, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit', textDecoration: 'none', transition: 'opacity .15s' }}
              onMouseEnter={e => (e.currentTarget.style.opacity = '0.88')}
              onMouseLeave={e => (e.currentTarget.style.opacity = '1')}
            >
              Find a centre near you
            </Link>
            <a
              href="tel:08001234567"
              style={{ padding: '14px 24px', border: '1px solid rgba(255,255,255,.2)', borderRadius: 10, background: 'transparent', color: 'rgba(255,255,255,.65)', fontSize: 15, cursor: 'pointer', fontFamily: 'inherit', textDecoration: 'none' }}
            >
              Call 0800 123 4567
            </a>
          </div>
          <div style={{ marginTop: 28, display: 'flex', gap: 24, justifyContent: 'center', flexWrap: 'wrap' }}>
            {['No referral needed', 'CQC registered centres', 'Free cancellation', 'Stripe secure payment'].map((t, i) => (
              <div key={i} style={{ fontSize: 12, color: 'rgba(255,255,255,.3)', display: 'flex', alignItems: 'center', gap: 5 }}>
                <span style={{ color: '#00C9A7' }}>✓</span> {t}
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </>
  )
}
