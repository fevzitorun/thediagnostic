'use client'

// ─── SERVICES PAGE ─────────────────────────────────────────────────────────────
// app/services/page.tsx
//
// Shows all available scan types in a clean grid.
// Links to individual service pages: /services/[scanType]
// Also shows body part quick-links and a search strip.

import Link from 'next/link'
import { Header, Footer, Breadcrumb } from '@/components/layout'

// ─── DATA ─────────────────────────────────────────────────────────────────────

const DIAGNOSTIC_SCANS = [
  {
    slug: 'mri-scan',
    label: 'MRI Scan',
    sub: 'From £275',
    icon: '🧲',
    badge: null,
    desc: 'High-resolution imaging of soft tissue, joints, brain and spine. No radiation. 1.5T and 3T scanners available.',
    highlights: ['No ionising radiation', 'Soft tissue & joint detail', '1.5T and 3T available', 'Report in 24–48h'],
    bodyParts: ['Brain', 'Spine', 'Knee', 'Shoulder', 'Hip', 'Abdomen'],
  },
  {
    slug: 'open-mri',
    label: 'Open & Upright MRI',
    sub: 'From £320',
    icon: '🧲',
    badge: 'Claustrophobia-friendly',
    desc: 'Open-bore and upright MRI scanners for patients with claustrophobia, larger body size, or pain on lying flat.',
    highlights: ['Open or upright scanner', 'No enclosed tunnel', 'Weight limit up to 250kg', 'Report in 24–48h'],
    bodyParts: ['Spine', 'Knee', 'Shoulder', 'Hip'],
  },
  {
    slug: 'ct-scan',
    label: 'CT Scan',
    sub: 'From £185',
    icon: '🔬',
    badge: null,
    desc: 'Fast, detailed cross-sectional imaging for chest, abdomen, head and spine. Results in 24 hours.',
    highlights: ['Results in 24h', 'Chest, abdomen, head', 'Contrast available', '15–20 min scan'],
    bodyParts: ['Chest', 'Abdomen', 'Head', 'Coronary', 'Spine'],
  },
  {
    slug: 'ultrasound',
    label: 'Ultrasound',
    sub: 'From £99',
    icon: '🔊',
    badge: null,
    desc: 'Real-time imaging using sound waves. Safe for all patients, no radiation. Abdomen, pelvis, thyroid, MSK and vascular.',
    highlights: ['No radiation', 'Safe in pregnancy', 'Abdominal, pelvic, MSK', 'Same-day results'],
    bodyParts: ['Abdomen', 'Pelvis', 'Thyroid', 'Breast', 'MSK'],
  },
  {
    slug: 'x-ray',
    label: 'X-Ray',
    sub: 'From £75',
    icon: '🦴',
    badge: 'Fastest & lowest cost',
    desc: 'Fast, affordable imaging for bones and joints. In and out in under 30 minutes. Report within 24 hours.',
    highlights: ['In and out in 30 min', 'Chest, joints, spine', 'From £75', 'Report in 24h'],
    bodyParts: ['Chest', 'Knee', 'Shoulder', 'Spine', 'Wrist', 'Foot'],
  },
]

const SCREENING_SCANS = [
  {
    slug: 'baby-scan',
    label: 'Baby Scan',
    sub: 'From £89',
    icon: '👶',
    badge: 'Pregnancy',
    desc: 'Early reassurance, dating, gender reveal and 4D baby scans. Caring, specialist teams at every centre.',
    highlights: ['8 weeks to full term', 'Gender from 16 weeks', '3D and 4D available', 'Immediate results'],
  },
  {
    slug: 'full-body-mri',
    label: 'Full Body MRI',
    sub: 'From £1,450',
    icon: '🫀',
    badge: 'Health screening',
    desc: 'Comprehensive whole-body MRI screening. No radiation. Detect abnormalities before symptoms appear.',
    highlights: ['No ionising radiation', '3T scanner', 'Head to toe coverage', 'Report in 48–72h'],
  },
  {
    slug: 'mammogram',
    label: 'Mammogram',
    sub: 'From £149',
    icon: '⚕️',
    badge: null,
    desc: 'Private mammography screening without waiting for NHS recall. Digital mammogram with same-day report.',
    highlights: ['No referral needed', 'Digital mammogram', 'Same-day report', 'Female radiographers'],
  },
  {
    slug: 'dexa-scan',
    label: 'DEXA Bone Density',
    sub: 'From £89',
    icon: '🦴',
    badge: null,
    desc: 'Osteoporosis screening and bone density measurement. Quick, low-dose scan with instant results.',
    highlights: ['15 min scan', 'Low dose X-Ray', 'Osteoporosis screening', 'Instant T-score result'],
  },
  {
    slug: 'echocardiogram',
    label: 'Echocardiogram',
    sub: 'From £249',
    icon: '❤️',
    badge: null,
    desc: 'Ultrasound imaging of the heart. Assess heart function, valves and structure without radiation.',
    highlights: ['No radiation', 'Heart function & valves', 'Resting echo', 'Report in 24h'],
  },
  {
    slug: 'prostate-screening',
    label: 'Prostate Screening',
    sub: 'From £495',
    icon: '🔬',
    badge: null,
    desc: 'PSA blood test + mpMRI prostate imaging. The most comprehensive private prostate health check available.',
    highlights: ['PSA + mpMRI', 'No biopsy needed first', 'Urology report', 'Seen within 1 week'],
  },
]

// ─── SCAN CARD (larger, for services page) ────────────────────────────────────

interface ServiceCardProps {
  slug: string
  label: string
  sub: string
  icon: string
  badge: string | null
  desc: string
  highlights: string[]
  bodyParts?: string[]
}

function ServiceCard(p: ServiceCardProps) {
  return (
    <div style={{ border: '1px solid #ebebeb', borderRadius: 18, background: '#fff', overflow: 'hidden', display: 'flex', flexDirection: 'column', transition: 'all .18s' }}
      onMouseEnter={e => { const el = e.currentTarget; el.style.borderColor = '#00C9A7'; el.style.boxShadow = '0 8px 32px rgba(0,201,167,.1)'; el.style.transform = 'translateY(-2px)' }}
      onMouseLeave={e => { const el = e.currentTarget; el.style.borderColor = '#ebebeb'; el.style.boxShadow = 'none'; el.style.transform = '' }}
    >
      {/* Card top */}
      <div style={{ padding: '24px 24px 20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
          <div style={{ width: 50, height: 50, borderRadius: 14, background: '#f8f8f8', display: 'grid', placeItems: 'center', fontSize: 26 }}>{p.icon}</div>
          {p.badge && (
            <span style={{ fontSize: 10, fontWeight: 600, padding: '3px 9px', borderRadius: 20, background: '#e6faf7', color: '#00a888', border: '1px solid #b2edd8', letterSpacing: 0.3 }}>
              {p.badge}
            </span>
          )}
        </div>

        <div style={{ fontSize: 18, fontWeight: 600, color: '#111', marginBottom: 4 }}>{p.label}</div>
        <div style={{ fontSize: 13, color: '#00a888', fontWeight: 500, marginBottom: 12 }}>{p.sub}</div>
        <p style={{ fontSize: 13, color: '#777', lineHeight: 1.65, margin: 0 }}>{p.desc}</p>
      </div>

      {/* Highlights */}
      <div style={{ padding: '0 24px 20px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
        {p.highlights.map((h, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: '#555' }}>
            <span style={{ color: '#00C9A7', fontWeight: 700, flexShrink: 0, fontSize: 10 }}>✓</span>{h}
          </div>
        ))}
      </div>

      {/* Body parts strip */}
      {p.bodyParts && p.bodyParts.length > 0 && (
        <div style={{ padding: '12px 24px', borderTop: '1px solid #f5f5f5', display: 'flex', gap: 5, flexWrap: 'wrap' }}>
          {p.bodyParts.map(bp => (
            <span key={bp} style={{ fontSize: 11, padding: '2px 8px', borderRadius: 20, background: '#f8f8f8', color: '#888', border: '1px solid #ebebeb' }}>{bp}</span>
          ))}
        </div>
      )}

      {/* CTA */}
      <div style={{ padding: '16px 24px', borderTop: '1px solid #f5f5f5', marginTop: 'auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Link
          href={`/services/${p.slug}`}
          style={{ fontSize: 13, fontWeight: 600, color: '#111', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 5 }}
        >
          View & book →
        </Link>
        <Link
          href={`/search?type=${p.slug}`}
          style={{ fontSize: 12, padding: '7px 14px', border: '1.5px solid #00C9A7', borderRadius: 8, color: '#00a888', textDecoration: 'none', fontWeight: 500, transition: 'all .15s' }}
          onMouseEnter={e => { e.currentTarget.style.background = '#00C9A7'; e.currentTarget.style.color = '#fff' }}
          onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = '#00a888' }}
        >
          Find centres
        </Link>
      </div>
    </div>
  )
}

// ─── PAGE ─────────────────────────────────────────────────────────────────────

export default function ServicesPage() {
  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'DM Sans', sans-serif; background: #fff; color: #222; -webkit-font-smoothing: antialiased; }
      `}</style>

      <Header />

      <Breadcrumb items={[
        { label: 'Home', href: '/' },
        { label: 'Services' },
      ]} />

      {/* HERO */}
      <div style={{ maxWidth: 1180, margin: '0 auto', padding: '56px 48px 0' }}>
        <div style={{ maxWidth: 640 }}>
          <div style={{ fontSize: 10, letterSpacing: 3, color: '#bbb', fontWeight: 500, marginBottom: 14, textTransform: 'uppercase' }}>All services</div>
          <h1 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 48, lineHeight: 1.1, letterSpacing: -1.5, color: '#111', marginBottom: 16 }}>
            Private scans,<br /><em style={{ fontStyle: 'italic', color: '#00C9A7' }}>no referral needed.</em>
          </h1>
          <p style={{ fontSize: 16, color: '#666', lineHeight: 1.8, marginBottom: 0 }}>
            Book MRI, CT, ultrasound, X-Ray and specialist screening scans at CQC-registered centres across the UK. All prices include a full radiologist's report.
          </p>
        </div>

        {/* Quick filters */}
        <div style={{ display: 'flex', gap: 8, marginTop: 28, flexWrap: 'wrap' }}>
          {[
            { label: 'All scans', href: '/services', active: true },
            { label: 'MRI', href: '/services/mri-scan' },
            { label: 'CT', href: '/services/ct-scan' },
            { label: 'Ultrasound', href: '/services/ultrasound' },
            { label: 'X-Ray', href: '/services/x-ray' },
            { label: 'Baby scans', href: '/services/baby-scan' },
            { label: 'Screening', href: '/services/full-body-mri' },
          ].map(filter => (
            <Link
              key={filter.label}
              href={filter.href}
              style={{ fontSize: 13, padding: '7px 14px', borderRadius: 20, border: `1.5px solid ${filter.active ? '#111' : '#ebebeb'}`, background: filter.active ? '#111' : '#fff', color: filter.active ? '#fff' : '#666', textDecoration: 'none', fontWeight: filter.active ? 500 : 400, transition: 'all .15s' }}
            >
              {filter.label}
            </Link>
          ))}
        </div>
      </div>

      {/* DIAGNOSTIC SCANS */}
      <div style={{ maxWidth: 1180, margin: '0 auto', padding: '48px 48px 0' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 12, marginBottom: 24 }}>
          <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 28, letterSpacing: -0.6, color: '#111' }}>Diagnostic imaging</h2>
          <span style={{ fontSize: 12, color: '#bbb' }}>5 scan types</span>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
          {DIAGNOSTIC_SCANS.map(scan => <ServiceCard key={scan.slug} {...scan} />)}
        </div>
      </div>

      {/* SCREENING & PREVENTATIVE */}
      <div style={{ maxWidth: 1180, margin: '0 auto', padding: '56px 48px 72px' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 12, marginBottom: 24 }}>
          <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 28, letterSpacing: -0.6, color: '#111' }}>Screening & preventative</h2>
          <span style={{ fontSize: 12, color: '#bbb' }}>6 scan types</span>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
          {SCREENING_SCANS.map(scan => <ServiceCard key={scan.slug} {...scan} />)}
        </div>
      </div>

      {/* NEED HELP STRIP */}
      <div style={{ background: '#f8f8f8', borderTop: '1px solid #ebebeb', borderBottom: '1px solid #ebebeb', padding: '32px 48px' }}>
        <div style={{ maxWidth: 1180, margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 20 }}>
          <div>
            <div style={{ fontSize: 15, fontWeight: 600, color: '#111', marginBottom: 4 }}>Not sure which scan you need?</div>
            <div style={{ fontSize: 13, color: '#888' }}>Our team can help you find the right scan for your symptoms. Call free or send a message.</div>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <a href="tel:08001234567" style={{ padding: '10px 20px', border: '1.5px solid #ebebeb', borderRadius: 9, background: '#fff', fontSize: 13, fontWeight: 500, color: '#111', textDecoration: 'none' }}>
              Call 0800 123 4567
            </a>
            <Link href="/contact" style={{ padding: '10px 20px', border: 'none', borderRadius: 9, background: '#111', fontSize: 13, fontWeight: 500, color: '#fff', textDecoration: 'none' }}>
              Send a message
            </Link>
          </div>
        </div>
      </div>

      {/* CTA */}
      <section style={{ background: '#111', padding: '72px 48px', textAlign: 'center' }}>
        <div style={{ maxWidth: 560, margin: '0 auto' }}>
          <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 40, color: '#fff', marginBottom: 12, letterSpacing: -1, lineHeight: 1.15 }}>
            Ready to book?<br /><em style={{ fontStyle: 'italic', color: '#00C9A7' }}>Find a centre today.</em>
          </h2>
          <p style={{ fontSize: 14, color: 'rgba(255,255,255,.4)', marginBottom: 32 }}>No GP referral. CQC registered centres. Fixed prices.</p>
          <Link
            href="/search"
            style={{ display: 'inline-block', padding: '14px 32px', border: 'none', borderRadius: 10, background: '#00C9A7', color: '#fff', fontSize: 15, fontWeight: 600, textDecoration: 'none', transition: 'opacity .15s' }}
            onMouseEnter={e => (e.currentTarget.style.opacity = '0.88')}
            onMouseLeave={e => (e.currentTarget.style.opacity = '1')}
          >
            Find a centre near you →
          </Link>
        </div>
      </section>

      <Footer />
    </>
  )
}
