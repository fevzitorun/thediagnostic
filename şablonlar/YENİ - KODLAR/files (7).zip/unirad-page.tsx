'use client'

// ─── UNIRAD CLINIC PAGE ───────────────────────────────────────────────────────
// app/centres/unirad-london/page.tsx
//
// TODO Enes: slug'ı params'dan al ve prisma.clinic.findUnique({ where: { slug } }) ile çek
// Unirad farkı: sadece MRI var, 1.5T scanner — sidebar daha basit, scan tabs yok

import { useState } from 'react'
import Link from 'next/link'

// ─── UNIRAD DATA ──────────────────────────────────────────────────────────────

const UNIRAD = {
  id: 'unirad-london',
  slug: 'unirad-london',
  name: 'Unirad Imaging',
  subtitle: 'Specialist MRI Centre',
  city: 'London',
  address: '14 Wimpole Street, London',
  postcode: 'W1G 9SU',
  phone: '020 7946 0123',
  rating: 4.7,
  reviewCount: 189,
  googleRating: 4.7,
  googleReviewCount: 134,
  doctifyRating: 4.8,
  doctifyReviewCount: 55,
  scannerTesla: '1.5T' as const,
  cqcRating: 'Good' as const,
  reportHours: 48,
  priceFrom: 195,
  openNow: true,
  // Only MRI — no CT, no ultrasound, no X-Ray
  scansOffered: ['MRI'] as const,
  hours: [
    { day: 'Monday',    time: '8am – 6pm' },
    { day: 'Tuesday',   time: '8am – 6pm' },
    { day: 'Wednesday', time: '8am – 6pm', isToday: true },
    { day: 'Thursday',  time: '8am – 6pm' },
    { day: 'Friday',    time: '8am – 5pm' },
    { day: 'Saturday',  time: '9am – 1pm' },
    { day: 'Sunday',    time: 'Closed' },
  ],
  facilities: [
    '1.5T MRI Scanner',
    'Dedicated MRI reporting suite',
    'Wheelchair accessible',
    'Step-free access from street',
    'Near Regent's Park tube',
  ],
  transport: [
    { icon: '🚇', text: '3 min walk from Regent's Park (Bakerloo line)' },
    { icon: '🚇', text: 'Bond Street station 10 min walk' },
    { icon: '🚌', text: 'Bus routes 88, 453 stop on Wimpole Street' },
    { icon: '♿', text: 'Step-free access throughout' },
  ],
  insurers: ['Bupa', 'AXA', 'Aviva'],
  packages: [
    { id: 'mri-1',    name: 'MRI — 1 Body Part',     price: 195, duration: '45 min', tag: 'popular' as const, reportHours: 48 },
    { id: 'mri-2',    name: 'MRI — 2 Body Parts',    price: 340, duration: '75 min', tag: null,               reportHours: 48 },
    { id: 'mri-3',    name: 'MRI — 3 Body Parts',    price: 450, duration: '90 min', tag: null,               reportHours: 72 },
    { id: 'mri-full', name: 'Full Body MRI',          price: 1200, duration: '3 hrs', tag: null,              reportHours: 72 },
  ],
  bodyParts: [
    'Brain & Head', 'Cervical Spine', 'Thoracic Spine', 'Lumbar Spine',
    'Knee', 'Shoulder', 'Hip', 'Wrist', 'Elbow', 'Foot & Ankle',
    'Abdomen', 'Pelvis', 'Liver', 'Prostate (mpMRI)',
  ],
  reviews: [
    { author: 'Rachel T.', date: '3 weeks ago', rating: 5, text: 'Very professional team. The 1.5T scanner produced excellent images for my knee — my orthopaedic consultant was very happy with the report quality.', scanType: 'MRI Knee' },
    { author: 'Oliver M.', date: '1 month ago', rating: 5, text: 'Convenient location, easy to book online, and the report arrived within 48 hours as promised. Stress-free experience from start to finish.', scanType: 'MRI Lumbar Spine' },
    { author: 'Nina P.', date: '6 weeks ago', rating: 4, text: 'Good clinic, clean and well-run. The 1.5T scanner was fine for my shoulder scan. Slightly longer wait time than expected but worth it for the price.', scanType: 'MRI Shoulder' },
    { author: 'Tom B.', date: '2 months ago', rating: 5, text: 'Reasonable price, quick report, and a very calm atmosphere. The radiographer took time to explain what would happen before starting.', scanType: 'MRI Brain' },
  ],
}

// ─── HELPERS ─────────────────────────────────────────────────────────────────

function Stars({ rating, size = 12 }: { rating: number; size?: number }) {
  return (
    <span style={{ color: '#f59e0b', fontSize: size, letterSpacing: 1 }}>
      {'★'.repeat(Math.floor(rating))}{'☆'.repeat(5 - Math.floor(rating))}
    </span>
  )
}

// ─── TESLA EXPLAINER (important for 1.5T pages) ───────────────────────────────

function TeslaNote() {
  return (
    <div style={{ background: '#f8f8f8', border: '1px solid #ebebeb', borderRadius: 12, padding: '18px 20px', marginTop: 24 }}>
      <div style={{ fontSize: 13, fontWeight: 600, color: '#111', marginBottom: 8, display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{ background: '#e0e7ff', color: '#4338ca', fontSize: 10, fontWeight: 700, padding: '2px 8px', borderRadius: 4, letterSpacing: 0.5, textTransform: 'uppercase' }}>1.5T scanner</span>
        Is this the right scanner for me?
      </div>
      <p style={{ fontSize: 13, color: '#555', lineHeight: 1.7, margin: 0 }}>
        Unirad operates a 1.5 Tesla MRI scanner — the UK standard for the vast majority of diagnostic imaging. 
        For routine musculoskeletal scans (knee, shoulder, spine, hip) and most abdominal and pelvic studies, 
        a 1.5T scanner produces excellent diagnostic quality images at a lower cost than 3T centres. 
        If your consultant has specifically requested a 3T scan — for example for neurological or cardiac imaging — 
        we can refer you to a partner centre with 3T capability.
      </p>
    </div>
  )
}

// ─── BOOKING SIDEBAR (MRI only — simpler than Medicana) ──────────────────────

function UniradSidebar() {
  const today = new Date()
  const days = Array.from({ length: 5 }, (_, i) => {
    const d = new Date(today)
    d.setDate(today.getDate() + i)
    return {
      label: i === 0 ? 'Today' : d.toLocaleDateString('en-GB', { weekday: 'short' }),
      num: d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }),
    }
  })

  const [selectedPkg, setSelectedPkg] = useState('mri-1')
  const [selectedBodyPart, setSelectedBodyPart] = useState('')
  const [selectedDate, setSelectedDate] = useState(0)

  const pkg = UNIRAD.packages.find(p => p.id === selectedPkg)!

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

      {/* BOOKING CARD */}
      <div style={{ background: '#fff', border: '1px solid #ebebeb', borderRadius: 16, padding: '24px 20px' }}>
        <div style={{ fontSize: 11, color: '#999', fontWeight: 500, textTransform: 'uppercase', letterSpacing: 1.5, marginBottom: 4 }}>MRI scans from</div>
        <div style={{ marginBottom: 20, display: 'flex', alignItems: 'baseline', gap: 8 }}>
          <span style={{ fontFamily: "'Instrument Serif', serif", fontSize: 38, color: '#111' }}>£{UNIRAD.priceFrom}</span>
          <span style={{ fontSize: 13, color: '#999' }}>per scan</span>
          {/* Price comparison note */}
          <span style={{ fontSize: 11, color: '#00a888', background: '#e6faf7', padding: '2px 8px', borderRadius: 20, fontWeight: 500 }}>Save vs 3T</span>
        </div>

        {/* Package select */}
        <div style={{ marginBottom: 14 }}>
          <label style={{ fontSize: 10, fontWeight: 700, color: '#bbb', letterSpacing: 1.5, textTransform: 'uppercase', display: 'block', marginBottom: 6 }}>Scan package</label>
          <select
            value={selectedPkg}
            onChange={e => { setSelectedPkg(e.target.value); setSelectedBodyPart('') }}
            style={{ width: '100%', padding: '10px 12px', border: '1.5px solid #ebebeb', borderRadius: 9, fontSize: 13, fontFamily: 'inherit', color: '#222', background: '#fff', outline: 'none' }}
          >
            {UNIRAD.packages.map(p => (
              <option key={p.id} value={p.id}>{p.name} — £{p.price}</option>
            ))}
          </select>
        </div>

        {/* Body part — always shown for MRI */}
        {selectedPkg !== 'mri-full' && (
          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: 10, fontWeight: 700, color: '#bbb', letterSpacing: 1.5, textTransform: 'uppercase', display: 'block', marginBottom: 6 }}>Body part</label>
            <select
              value={selectedBodyPart}
              onChange={e => setSelectedBodyPart(e.target.value)}
              style={{ width: '100%', padding: '10px 12px', border: '1.5px solid #ebebeb', borderRadius: 9, fontSize: 13, fontFamily: 'inherit', color: selectedBodyPart ? '#222' : '#bbb', background: '#fff', outline: 'none' }}
            >
              <option value="">Choose a body part…</option>
              {UNIRAD.bodyParts.map(bp => <option key={bp} value={bp}>{bp}</option>)}
            </select>
          </div>
        )}

        {/* Date */}
        <div style={{ marginBottom: 20 }}>
          <label style={{ fontSize: 10, fontWeight: 700, color: '#bbb', letterSpacing: 1.5, textTransform: 'uppercase', display: 'block', marginBottom: 6 }}>Preferred date</label>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 5 }}>
            {days.map((d, i) => (
              <button
                key={i}
                onClick={() => setSelectedDate(i)}
                style={{ padding: '8px 4px', border: `1.5px solid ${selectedDate === i ? '#00C9A7' : '#ebebeb'}`, borderRadius: 9, background: selectedDate === i ? '#e6faf7' : '#fff', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2 }}
              >
                <span style={{ fontSize: 10, color: selectedDate === i ? '#00a888' : '#999', fontWeight: 600 }}>{d.label}</span>
                <span style={{ fontSize: 11, color: selectedDate === i ? '#00a888' : '#333', fontWeight: selectedDate === i ? 600 : 400 }}>{d.num}</span>
              </button>
            ))}
          </div>
        </div>

        <button
          style={{ width: '100%', padding: '13px 0', background: '#00C9A7', color: '#fff', border: 'none', borderRadius: 10, fontSize: 15, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit' }}
          onMouseEnter={e => (e.currentTarget.style.opacity = '0.88')}
          onMouseLeave={e => (e.currentTarget.style.opacity = '1')}
        >
          Check Availability →
        </button>

        <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 7 }}>
          {['Free cancellation up to 24 hours before', 'CQC registered — Good rating', 'Secure payment via Stripe'].map((n, i) => (
            <div key={i} style={{ display: 'flex', gap: 7, fontSize: 12, color: '#999' }}>
              <span style={{ color: '#00C9A7', fontWeight: 700, flexShrink: 0 }}>✓</span>{n}
            </div>
          ))}
        </div>
      </div>

      {/* PRICE SUMMARY */}
      <div style={{ background: '#fff', border: '1px solid #ebebeb', borderRadius: 16, padding: '18px 20px' }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: '#111', marginBottom: 14 }}>Price summary</div>
        {[
          { label: pkg.name, value: `£${pkg.price}` },
          { label: "Radiologist's report", value: 'Included' },
          { label: 'Digital images', value: 'Included' },
          { label: 'ScanBook fee', value: '£0' },
        ].map((row, i) => (
          <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '7px 0', borderBottom: i < 3 ? '1px solid #f5f5f5' : 'none', fontSize: i === 3 ? 14 : 13, fontWeight: i === 3 ? 600 : 400 }}>
            <span style={{ color: i < 3 ? '#666' : '#111' }}>{row.label}</span>
            <span style={{ color: i === 3 ? '#111' : '#444' }}>{row.value}</span>
          </div>
        ))}
      </div>

      {/* HOURS */}
      <div style={{ background: '#fff', border: '1px solid #ebebeb', borderRadius: 16, padding: '18px 20px' }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: '#111', marginBottom: 14 }}>Opening hours</div>
        {UNIRAD.hours.map((h, i) => (
          <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: i < UNIRAD.hours.length - 1 ? '1px solid #f5f5f5' : 'none', fontSize: 12 }}>
            <span style={{ color: h.isToday ? '#111' : '#666', fontWeight: h.isToday ? 600 : 400 }}>{h.day}{h.isToday ? ' (today)' : ''}</span>
            <span style={{ color: h.time === 'Closed' ? '#f87171' : h.isToday ? '#00a888' : '#444', fontWeight: h.isToday ? 600 : 400, display: 'flex', alignItems: 'center', gap: 5 }}>
              {h.time}{h.isToday && h.time !== 'Closed' && <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#00C9A7', display: 'inline-block' }} />}
            </span>
          </div>
        ))}
      </div>

      {/* FACILITIES */}
      <div style={{ background: '#fff', border: '1px solid #ebebeb', borderRadius: 16, padding: '18px 20px' }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: '#111', marginBottom: 12 }}>Facilities</div>
        {UNIRAD.facilities.map((f, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 9, fontSize: 13, color: '#444', marginBottom: i < UNIRAD.facilities.length - 1 ? 8 : 0 }}>
            <span style={{ color: '#00C9A7', fontWeight: 700, flexShrink: 0 }}>✓</span>{f}
          </div>
        ))}
      </div>

    </div>
  )
}

// ─── PAGE ─────────────────────────────────────────────────────────────────────

export default function UniradPage() {
  const [expandedBP, setExpandedBP] = useState(false)

  return (
    <>
      <style>{`
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'DM Sans', sans-serif; background: #fff; color: #222; -webkit-font-smoothing: antialiased; }
      `}</style>

      {/* NAV */}
      <nav style={{ height: 60, padding: '0 48px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid #ebebeb', position: 'sticky', top: 0, background: '#fff', zIndex: 200 }}>
        <Link href="/" style={{ display: 'flex', alignItems: 'center', textDecoration: 'none' }}>
          <span style={{ fontFamily: "'Helvetica Neue', sans-serif", fontSize: 20, fontWeight: 700, color: '#111' }}>Scan</span>
          <span style={{ fontFamily: "'Helvetica Neue', sans-serif", fontSize: 20, fontWeight: 700, color: '#00C9A7' }}>Book</span>
        </Link>
        <div style={{ display: 'flex', gap: 4 }}>
          {['Services', 'How it works', 'Find a Centre', 'For Clinics', 'Blog'].map(l => (
            <a key={l} href="#" style={{ padding: '7px 12px', fontSize: 13, color: '#666', textDecoration: 'none', borderRadius: 7 }}>{l}</a>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button style={{ padding: '7px 16px', border: '1.5px solid #ebebeb', borderRadius: 7, background: '#fff', fontSize: 13, cursor: 'pointer', fontFamily: 'inherit' }}>Sign In</button>
          <button style={{ padding: '8px 18px', border: 'none', borderRadius: 7, background: '#00C9A7', color: '#fff', fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>Book a Scan</button>
        </div>
      </nav>

      {/* BREADCRUMB */}
      <div style={{ padding: '10px 48px', fontSize: 12, color: '#bbb', borderBottom: '1px solid #f5f5f5' }}>
        <Link href="/" style={{ color: '#999', textDecoration: 'none' }}>Home</Link> /{' '}
        <Link href="/centres" style={{ color: '#999', textDecoration: 'none' }}>Imaging Centres</Link> /{' '}
        <Link href="/centres/london" style={{ color: '#999', textDecoration: 'none' }}>London</Link> /{' '}
        <span style={{ color: '#444' }}>Unirad Imaging</span>
      </div>

      {/* GALLERY */}
      <div style={{ maxWidth: 1180, margin: '0 auto', padding: '28px 48px 0' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr', gridTemplateRows: '200px 200px', gap: 8, borderRadius: 16, overflow: 'hidden' }}>
          {[
            { label: '🏥', big: true, bg: '#eef5f2' },
            { label: '🧲', bg: '#eeeff5' },
            { label: '🛋️', bg: '#f5f2ee' },
            { label: '📋', bg: '#f0f5ee' },
            { label: '🔬', bg: '#f5eeee' },
          ].map((c, i) => (
            <div key={i} style={{ background: c.bg, display: 'grid', placeItems: 'center', fontSize: c.big ? 56 : 32, color: '#ccc', cursor: 'pointer', gridRow: c.big ? 'span 2' : undefined, border: '1px solid #ebebeb' }}>
              {c.label}
            </div>
          ))}
        </div>
      </div>

      {/* MAIN */}
      <div style={{ maxWidth: 1180, margin: '0 auto', padding: '28px 48px 60px', display: 'grid', gridTemplateColumns: '1fr 340px', gap: 28, alignItems: 'start' }}>

        {/* LEFT */}
        <div>

          {/* Header */}
          <div style={{ marginBottom: 20 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 16, marginBottom: 12 }}>
              <div>
                <h1 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 34, letterSpacing: -0.8, color: '#111', lineHeight: 1.15, marginBottom: 4 }}>
                  {UNIRAD.name}
                </h1>
                <div style={{ fontSize: 14, color: '#666' }}>{UNIRAD.subtitle}</div>
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 6 }}>
                <button style={{ padding: '8px 14px', border: '1.5px solid #ebebeb', borderRadius: 8, fontSize: 13, color: '#666', background: '#fff', cursor: 'pointer', fontFamily: 'inherit' }}>♡ Save</button>
                <button style={{ padding: '8px 14px', border: '1.5px solid #ebebeb', borderRadius: 8, fontSize: 13, color: '#666', background: '#fff', cursor: 'pointer', fontFamily: 'inherit' }}>↑ Share</button>
              </div>
            </div>

            {/* Meta */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap', fontSize: 13, color: '#666', marginBottom: 14 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontWeight: 600, color: '#111' }}>
                <Stars rating={UNIRAD.rating} size={13} />
                <span>{UNIRAD.rating}</span>
                <span style={{ fontSize: 13, color: '#999', fontWeight: 400 }}>({UNIRAD.reviewCount} reviews)</span>
              </div>
              <span>·</span>
              <span>{UNIRAD.city}</span>
              <span>·</span>
              <span style={{ color: '#00a888', fontWeight: 500 }}>● Open now</span>
            </div>

            {/* Badges — note: 1.5T badge is subdued vs Medicana's purple 3T */}
            <div style={{ display: 'flex', gap: 7, flexWrap: 'wrap' }}>
              {[
                { label: `CQC ${UNIRAD.cqcRating}`,     bg: '#e6faf7', color: '#00a888', border: '#b2edd8' },
                { label: '1.5T MRI Scanner',             bg: '#f1f5f9', color: '#475569', border: '#e2e8f0' },
                { label: `Report in ${UNIRAD.reportHours}h`, bg: '#f8f8f8', color: '#666', border: '#ebebeb' },
                { label: 'MRI specialist',               bg: '#f8f8f8', color: '#666', border: '#ebebeb' },
              ].map(b => (
                <span key={b.label} style={{ fontSize: 10, fontWeight: 600, padding: '3px 10px', borderRadius: 5, letterSpacing: 0.5, background: b.bg, color: b.color, border: `1px solid ${b.border}`, textTransform: 'uppercase' }}>
                  {b.label}
                </span>
              ))}
            </div>
          </div>

          {/* Overview pills */}
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 20 }}>
            {[`1.5T MRI`, `From £${UNIRAD.priceFrom}`, `${UNIRAD.reportHours}h report`, 'Step-free access', 'Wimpole Street'].map((pill, i) => (
              <div key={i} style={{ padding: '8px 14px', border: '1.5px solid #ebebeb', borderRadius: 9, fontSize: 13, color: '#222', background: '#fff', display: 'flex', alignItems: 'center', gap: 6 }}>
                <span style={{ color: '#00C9A7' }}>✓</span>{pill}
              </div>
            ))}
          </div>

          <div style={{ height: 1, background: '#ebebeb', margin: '20px 0' }} />

          {/* MRI Packages */}
          <div style={{ marginBottom: 32 }}>
            <div style={{ fontSize: 10, letterSpacing: 2.5, color: '#bbb', fontWeight: 500, marginBottom: 14, textTransform: 'uppercase' }}>MRI scans</div>
            <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 24, letterSpacing: -0.4, color: '#111', marginBottom: 16 }}>Book an MRI at Unirad</h2>

            {UNIRAD.packages.map(pkg => (
              <div
                key={pkg.id}
                style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '15px 17px', background: '#fff', borderRadius: 11, border: '1px solid #ebebeb', marginBottom: 8, cursor: 'pointer', transition: 'all 0.15s' }}
                onMouseEnter={e => { (e.currentTarget as HTMLDivElement).style.borderColor = '#00C9A7'; (e.currentTarget as HTMLDivElement).style.boxShadow = '0 3px 14px rgba(0,201,167,.07)' }}
                onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.borderColor = '#ebebeb'; (e.currentTarget as HTMLDivElement).style.boxShadow = 'none' }}
              >
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3 }}>
                    <span style={{ fontSize: 14, fontWeight: 500, color: '#111' }}>{pkg.name}</span>
                    {pkg.tag === 'popular' && <span style={{ fontSize: 9, fontWeight: 700, padding: '2px 7px', borderRadius: 4, background: '#fff8e6', color: '#b07800', textTransform: 'uppercase', letterSpacing: 0.3 }}>Most popular</span>}
                  </div>
                  <div style={{ fontSize: 12, color: '#bbb' }}>{pkg.duration} · Report in {pkg.reportHours}h</div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 14, flexShrink: 0 }}>
                  <span style={{ fontFamily: "'Instrument Serif', serif", fontSize: 21, color: '#111' }}>£{pkg.price}</span>
                  <button
                    style={{ padding: '8px 16px', border: '1.5px solid #00C9A7', borderRadius: 8, background: '#fff', color: '#00a888', fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit', transition: 'all 0.15s' }}
                    onMouseEnter={e => { e.currentTarget.style.background = '#00C9A7'; e.currentTarget.style.color = '#fff' }}
                    onMouseLeave={e => { e.currentTarget.style.background = '#fff'; e.currentTarget.style.color = '#00a888' }}
                  >
                    Book →
                  </button>
                </div>
              </div>
            ))}

            {/* Body parts grid */}
            <div style={{ marginTop: 20 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 13, fontWeight: 500, color: '#666', marginBottom: 11 }}>
                <span style={{ width: 3, height: 13, background: '#00C9A7', borderRadius: 2, flexShrink: 0, display: 'block' }} />
                Available body parts
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 6 }}>
                {UNIRAD.bodyParts.slice(0, expandedBP ? 99 : 8).map(bp => (
                  <div
                    key={bp}
                    style={{ padding: '9px 11px', border: '1px solid #ebebeb', borderRadius: 8, fontSize: 12, color: '#222', cursor: 'pointer', transition: 'all 0.15s', background: '#fff' }}
                    onMouseEnter={e => { (e.currentTarget as HTMLDivElement).style.borderColor = '#00C9A7'; (e.currentTarget as HTMLDivElement).style.background = '#e6faf7'; (e.currentTarget as HTMLDivElement).style.color = '#00a888' }}
                    onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.borderColor = '#ebebeb'; (e.currentTarget as HTMLDivElement).style.background = '#fff'; (e.currentTarget as HTMLDivElement).style.color = '#222' }}
                  >
                    {bp}
                  </div>
                ))}
                {!expandedBP && UNIRAD.bodyParts.length > 8 && (
                  <div onClick={() => setExpandedBP(true)} style={{ padding: '9px 11px', border: '1px dashed #ebebeb', borderRadius: 8, fontSize: 12, color: '#bbb', cursor: 'pointer', background: '#f8f8f8' }}>
                    +{UNIRAD.bodyParts.length - 8} more
                  </div>
                )}
              </div>
            </div>

            {/* 1.5T explainer */}
            <TeslaNote />
          </div>

          <div style={{ height: 1, background: '#ebebeb', margin: '20px 0' }} />

          {/* Reviews */}
          <div style={{ marginBottom: 32 }}>
            <div style={{ fontSize: 10, letterSpacing: 2.5, color: '#bbb', fontWeight: 500, marginBottom: 14, textTransform: 'uppercase' }}>Patient reviews</div>
            <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 24, letterSpacing: -0.4, color: '#111', marginBottom: 16 }}>What patients say</h2>
            <div style={{ display: 'flex', gap: 14, marginBottom: 20 }}>
              {[
                { name: 'Google', rating: UNIRAD.googleRating, count: UNIRAD.googleReviewCount, color: '#4285f4' },
                { name: 'Doctify', rating: UNIRAD.doctifyRating, count: UNIRAD.doctifyReviewCount, color: '#00c896' },
              ].map(s => (
                <div key={s.name} style={{ border: '1px solid #ebebeb', borderRadius: 12, padding: '16px 20px', background: '#fff', display: 'flex', alignItems: 'center', gap: 14, flex: 1 }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: s.color }}>{s.name}</div>
                  <div>
                    <div style={{ fontFamily: "'Instrument Serif', serif", fontSize: 28, color: '#111', lineHeight: 1 }}>{s.rating}</div>
                    <Stars rating={s.rating} />
                    <div style={{ fontSize: 11, color: '#bbb', marginTop: 1 }}>{s.count} reviews</div>
                  </div>
                </div>
              ))}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              {UNIRAD.reviews.map((r, i) => (
                <div key={i} style={{ background: '#f8f8f8', border: '1px solid #ebebeb', borderRadius: 11, padding: 18 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 600, color: '#111', marginBottom: 2 }}>{r.author}</div>
                      <div style={{ fontSize: 11, color: '#00a888', fontWeight: 500 }}>{r.scanType}</div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <Stars rating={r.rating} />
                      <div style={{ fontSize: 11, color: '#bbb', marginTop: 2 }}>{r.date}</div>
                    </div>
                  </div>
                  <p style={{ fontSize: 13, color: '#555', lineHeight: 1.6, margin: 0 }}>{r.text}</p>
                </div>
              ))}
            </div>
          </div>

          <div style={{ height: 1, background: '#ebebeb', margin: '20px 0' }} />

          {/* About */}
          <div style={{ marginBottom: 32 }}>
            <div style={{ fontSize: 10, letterSpacing: 2.5, color: '#bbb', fontWeight: 500, marginBottom: 14, textTransform: 'uppercase' }}>About</div>
            <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 24, letterSpacing: -0.4, color: '#111', marginBottom: 16 }}>About Unirad Imaging</h2>
            <p style={{ fontSize: 14, color: '#555', lineHeight: 1.75, marginBottom: 12 }}>
              Unirad Imaging is a specialist MRI centre on Wimpole Street, London, dedicated exclusively to magnetic resonance imaging. With a focus on quality and accessibility, Unirad provides a fast, affordable alternative to hospital waiting lists for patients who need a private MRI scan.
            </p>
            <p style={{ fontSize: 14, color: '#555', lineHeight: 1.75 }}>
              The centre's 1.5 Tesla MRI scanner is ideal for the vast majority of diagnostic scans, including musculoskeletal, abdominal, pelvic, and neurological studies. All scans are reported by a UK-based consultant radiologist, with reports delivered within 48 hours via a secure patient portal.
            </p>
            <div style={{ marginTop: 20 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: '#111', marginBottom: 10 }}>Insurance accepted</div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                {UNIRAD.insurers.map(ins => (
                  <span key={ins} style={{ fontSize: 12, padding: '5px 12px', borderRadius: 7, border: '1px solid #ebebeb', color: '#444', background: '#f8f8f8' }}>{ins}</span>
                ))}
                <span style={{ fontSize: 12, padding: '5px 12px', borderRadius: 7, border: '1px solid #ebebeb', color: '#bbb', background: '#f8f8f8' }}>Self-pay welcome</span>
              </div>
            </div>
          </div>

          <div style={{ height: 1, background: '#ebebeb', margin: '20px 0' }} />

          {/* Location */}
          <div style={{ marginBottom: 32 }}>
            <div style={{ fontSize: 10, letterSpacing: 2.5, color: '#bbb', fontWeight: 500, marginBottom: 14, textTransform: 'uppercase' }}>Location</div>
            <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 24, letterSpacing: -0.4, color: '#111', marginBottom: 16 }}>Getting here</h2>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
              <div style={{ background: '#f0f0f0', borderRadius: 14, height: 200, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 32, color: '#ccc', border: '1px solid #ebebeb' }}>
                🗺️
                {/* TODO Enes: Google Maps embed */}
              </div>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600, color: '#111', marginBottom: 4 }}>{UNIRAD.name}</div>
                <div style={{ fontSize: 13, color: '#666', marginBottom: 18 }}>{UNIRAD.address}<br />{UNIRAD.postcode}</div>
                {UNIRAD.transport.map((t, i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 10, fontSize: 13, color: '#444', marginBottom: 10 }}>
                    <span style={{ width: 28, height: 28, background: '#f8f8f8', border: '1px solid #ebebeb', borderRadius: 7, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, flexShrink: 0 }}>{t.icon}</span>
                    {t.text}
                  </div>
                ))}
              </div>
            </div>
          </div>

        </div>

        {/* SIDEBAR */}
        <div style={{ position: 'sticky', top: 76 }}>
          <UniradSidebar />
        </div>

      </div>

      {/* FOOTER */}
      <footer style={{ borderTop: '1px solid #ebebeb', padding: '20px 48px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: 12, color: '#bbb' }}>
        <span><span style={{ fontWeight: 700, color: '#111' }}>Scan</span><span style={{ fontWeight: 700, color: '#00C9A7' }}>Book</span></span>
        <span>© 2025 The Connective UK Ltd · CQC Partner Network · Registered in England and Wales</span>
        <div style={{ display: 'flex', gap: 20 }}>
          {['Privacy', 'Terms', 'Cookies'].map(l => <a key={l} href="#" style={{ color: '#bbb', textDecoration: 'none' }}>{l}</a>)}
        </div>
      </footer>
    </>
  )
}
