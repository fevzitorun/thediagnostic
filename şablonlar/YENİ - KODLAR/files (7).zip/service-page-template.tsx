'use client'

// ─── SCAN SERVICE PAGE TEMPLATE ───────────────────────────────────────────────
// app/services/[scanType]/page.tsx
//
// Bu tek dosya MRI, CT, Ultrasound ve X-Ray sayfalarını üretir.
// Enes sadece SCAN_CONFIG objesini genişletir — başka dosya yazmaz.
//
// Kullanım:
//   /services/mri-scan        → MRI sayfası
//   /services/ct-scan         → CT sayfası
//   /services/ultrasound      → Ultrasound sayfası
//   /services/x-ray           → X-Ray sayfası
//
// TODO Enes: generateStaticParams ekle:
//   export function generateStaticParams() {
//     return Object.keys(SCAN_CONFIG).map(slug => ({ scanType: slug }))
//   }

import { useState } from 'react'
import Link from 'next/link'

// ─── TYPES ────────────────────────────────────────────────────────────────────

interface PricePackage {
  label: string
  price: number
  featured?: boolean
}

interface BodyPartCard {
  name: string
  desc: string
  icon: string
  slug: string
}

interface ProcessStep {
  title: string
  text: string
}

interface FAQ {
  q: string
  a: string
}

interface ScanConfig {
  slug: string
  title: string            // "Private MRI Scan"
  titleItalic: string      // "across the UK" (green italic part)
  category: string         // "DIAGNOSTIC SCANS"
  lead: string
  priceFrom: number
  priceSuffix: string      // "per scan" | "per area"
  trustItems: { label: string; sub: string }[]
  packages: PricePackage[]
  // Booking widget
  packageLabel: string     // "BODY PARTS" | "SCAN TYPE" | "AREA"
  packageOptions: string[]
  bodyPartGroups: { group: string; items: string[] }[]
  // Body part cards
  bodyParts: BodyPartCard[]
  // What to expect
  processSteps: ProcessStep[]
  // What's included
  included: string[]
  notes: string[]
  // SEO/clinical content
  aboutTitle: string
  aboutBody: string[]
  // Tesla note — only for MRI
  teslaNote?: string
  // FAQ
  faqs: FAQ[]
  // Related services (slugs)
  related: string[]
  // CTA
  ctaTitle: string
  ctaItalic: string
  ctaSub: string
  // Meta
  metaTitle: string
  metaDescription: string
}

// ─── SCAN CONFIG ─────────────────────────────────────────────────────────────
// Enes: Her yeni scan tipi için buraya yeni obje ekle.

const SCAN_CONFIG: Record<string, ScanConfig> = {

  'mri-scan': {
    slug: 'mri-scan',
    title: 'Private MRI Scans',
    titleItalic: 'across the UK',
    category: 'DIAGNOSTIC SCANS',
    lead: 'Access over 600 accredited imaging centres without a GP referral. Choose your body part, find a centre near you, and receive a full radiologist\'s report within 24 to 48 hours.',
    priceFrom: 275,
    priceSuffix: 'per scan',
    metaTitle: 'Private MRI Scan UK | From £275 | No GP Referral | ScanBook',
    metaDescription: 'Book a private MRI scan at 600+ CQC-registered centres across the UK. No GP referral needed. Radiologist report in 24–48 hours. Transparent pricing from £275.',
    trustItems: [
      { label: 'No referral', sub: 'self-refer online' },
      { label: '600+', sub: 'partner centres' },
      { label: '24–48 hrs', sub: 'report turnaround' },
      { label: 'From £275', sub: 'transparent pricing' },
    ],
    packages: [
      { label: '1 BODY PART', price: 275 },
      { label: '2 BODY PARTS', price: 445 },
      { label: '3 BODY PARTS', price: 575 },
      { label: '4 BODY PARTS', price: 725 },
      { label: 'FULL BODY MRI', price: 1450, featured: true },
    ],
    packageLabel: 'BODY PARTS',
    packageOptions: [
      '1 Body Part — £275',
      '2 Body Parts — £445',
      '3 Body Parts — £575',
      '4 Body Parts — £725',
      'Full Body MRI — £1,450',
    ],
    bodyPartGroups: [
      { group: 'Head and Spine', items: ['Brain and Head', 'Cervical Spine (neck)', 'Thoracic Spine (mid-back)', 'Lumbar Spine (lower back)'] },
      { group: 'Joints', items: ['Knee', 'Shoulder', 'Hip', 'Wrist', 'Elbow', 'Foot and Ankle', 'Hand'] },
      { group: 'Abdomen and Pelvis', items: ['Abdomen', 'Pelvis', 'Liver', 'Kidney', 'Prostate (mpMRI)', 'MRCP (liver and pancreas)'] },
      { group: 'Other', items: ['Cardiac (heart)', 'Breast', 'Neck and Thyroid', 'Pituitary Gland', 'Sinuses', 'Full Body MRI'] },
    ],
    bodyParts: [
      { name: 'Knee MRI', desc: 'Ligament tears, cartilage damage, meniscal injury', icon: '🦵', slug: 'knee-mri' },
      { name: 'Brain MRI', desc: 'Headaches, neurological symptoms, tumour screening', icon: '🧠', slug: 'brain-mri' },
      { name: 'Lumbar Spine', desc: 'Lower back pain, disc herniation, sciatica', icon: '🦴', slug: 'lumbar-spine-mri' },
      { name: 'Shoulder MRI', desc: 'Rotator cuff tears, impingement, labral injury', icon: '💪', slug: 'shoulder-mri' },
      { name: 'Hip MRI', desc: 'Avascular necrosis, labral tears, groin pain', icon: '🦴', slug: 'hip-mri' },
      { name: 'Abdomen MRI', desc: 'Liver, kidneys, adrenals, pancreas', icon: '🫁', slug: 'abdomen-mri' },
      { name: 'Prostate MRI', desc: 'mpMRI for suspected prostate cancer (PSA raised)', icon: '⚕️', slug: 'prostate-mri' },
      { name: 'Full Body MRI', desc: 'Comprehensive whole-body cancer and health screening', icon: '🫀', slug: 'full-body-mri' },
    ],
    processSteps: [
      { title: 'Book online in minutes', text: 'Select your body part, choose a centre near you, and pick a date. No GP letter needed.' },
      { title: 'Attend your appointment', text: 'Arrive at your chosen centre. The scan takes 20–60 minutes depending on the area scanned.' },
      { title: 'Receive your report', text: 'A UK-based consultant radiologist reviews your images. Your written report is delivered to your secure portal within 24–48 hours.' },
      { title: 'Share with your doctor', text: 'Send your report and images directly to your GP, consultant, or specialist — via secure link or printed.' },
    ],
    included: [
      'Full consultant radiologist\'s report',
      'High-resolution digital images (DICOM format)',
      'Secure online patient portal access',
      'Shareable report link for your GP or consultant',
    ],
    notes: [
      'Contrast agent (gadolinium) available at selected centres — ask when booking',
      'Open MRI available at selected centres for patients with claustrophobia',
      '3T scanners available for neurological and cardiac cases',
    ],
    teslaNote: 'ScanBook partner centres operate both 1.5 Tesla and 3 Tesla MRI scanners. For routine musculoskeletal and abdominal scans, a 1.5T scanner produces excellent results. 3T scanners offer higher resolution for neurological, cardiac, and oncological imaging. If unsure which you need, our team can advise.',
    aboutTitle: 'Private MRI in the UK — what you need to know',
    aboutBody: [
      'An MRI (Magnetic Resonance Imaging) scan uses a strong magnetic field and radio waves to produce detailed images of the body\'s internal structures. Unlike CT scans, MRI uses no ionising radiation, making it the preferred choice for many soft tissue and neurological investigations.',
      'Through ScanBook, you can access over 600 CQC-registered private imaging centres across the UK, including 1.5T and 3T scanners. All scans are reported by a UK-based consultant radiologist, and results are delivered to your secure online portal within 24–48 hours.',
      'Common reasons people book a private MRI include musculoskeletal injuries (knee, shoulder, spine), neurological symptoms, abdominal investigations, and prostate screening. No GP referral is required.',
    ],
    faqs: [
      { q: 'Do I need a GP referral for a private MRI scan?', a: 'No. Through ScanBook you can self-refer and book directly online without a GP letter or referral. Simply choose your body part, select a centre, and book.' },
      { q: 'How long does an MRI scan take?', a: 'Most single-area MRI scans take 30–45 minutes in the scanner. A full body MRI takes around 2–3 hours. Allow extra time for check-in and preparation.' },
      { q: 'When will I get my MRI report?', a: 'All ScanBook partner centres provide a full written radiologist\'s report within 24–48 hours of your scan. Some centres offer same-day reports for an additional fee.' },
      { q: 'Is the MRI scan safe?', a: 'MRI uses magnetic fields and radio waves — no ionising radiation. It is safe for most people. You should inform the centre if you have a pacemaker, cochlear implant, metal implants, or are pregnant.' },
      { q: 'What is the difference between 1.5T and 3T MRI?', a: 'Tesla (T) refers to the magnetic field strength. 3T scanners produce higher resolution images, which is particularly beneficial for brain, cardiac, and oncological studies. For most musculoskeletal and routine body scans, 1.5T is excellent.' },
      { q: 'Can I use my health insurance?', a: 'Yes. We accept Bupa, AXA Health, Aviva, Vitality, WPA, and Cigna at most partner centres. Contact your insurer first to confirm coverage and obtain a pre-authorisation number.' },
    ],
    ctaTitle: 'Book your MRI scan',
    ctaItalic: 'today.',
    ctaSub: 'No referral needed. 600+ centres. Reports within 48 hours.',
    related: ['ct-scan', 'ultrasound', 'x-ray', 'full-body-mri'],
  },

  'ct-scan': {
    slug: 'ct-scan',
    title: 'Private CT Scans',
    titleItalic: 'fast, accurate imaging',
    category: 'DIAGNOSTIC SCANS',
    lead: 'Book a private CT scan at CQC-registered centres across the UK. Fast turnaround, no GP referral required. Detailed cross-sectional imaging reported by a consultant radiologist within 24 hours.',
    priceFrom: 185,
    priceSuffix: 'per scan',
    metaTitle: 'Private CT Scan UK | From £185 | No GP Referral | ScanBook',
    metaDescription: 'Book a private CT scan at accredited UK imaging centres. No GP referral needed. Radiologist report in 24 hours. Prices from £185.',
    trustItems: [
      { label: 'No referral', sub: 'self-refer online' },
      { label: '300+', sub: 'partner centres' },
      { label: '24 hrs', sub: 'report turnaround' },
      { label: 'From £185', sub: 'transparent pricing' },
    ],
    packages: [
      { label: 'CT HEAD', price: 185 },
      { label: 'CT CHEST', price: 199 },
      { label: 'CT ABDOMEN', price: 249 },
      { label: 'CT CHEST + ABD', price: 349 },
      { label: 'CT CORONARY', price: 595, featured: true },
    ],
    packageLabel: 'SCAN TYPE',
    packageOptions: [
      'CT Head — £185',
      'CT Chest — £199',
      'CT Abdomen & Pelvis — £249',
      'CT Chest + Abdomen — £349',
      'CT Coronary Angiogram — £595',
      'CT Pulmonary Angiogram (CTPA) — £295',
    ],
    bodyPartGroups: [
      { group: 'Head and Neck', items: ['Head and Brain', 'Sinuses', 'Neck'] },
      { group: 'Chest', items: ['Chest (lungs)', 'Pulmonary Angiogram (CTPA)', 'Cardiac / Coronary'] },
      { group: 'Abdomen and Pelvis', items: ['Abdomen', 'Pelvis', 'Abdomen + Pelvis', 'Renal / Urogram (KUB)'] },
      { group: 'Spine', items: ['Cervical Spine', 'Thoracic Spine', 'Lumbar Spine'] },
    ],
    bodyParts: [
      { name: 'CT Chest', desc: 'Lung nodules, pulmonary embolism, pneumonia follow-up', icon: '🫁', slug: 'ct-chest' },
      { name: 'CT Abdomen', desc: 'Abdominal pain, gallstones, kidney stones, bowel', icon: '🫀', slug: 'ct-abdomen' },
      { name: 'CT Head', desc: 'Headaches, sinus issues, head injury follow-up', icon: '🧠', slug: 'ct-head' },
      { name: 'CT Coronary', desc: 'Calcium scoring, coronary artery disease risk', icon: '❤️', slug: 'ct-coronary' },
      { name: 'CTPA', desc: 'Pulmonary embolism, blood clot in lungs', icon: '🫁', slug: 'ct-pulmonary-angiogram' },
      { name: 'CT Spine', desc: 'Disc problems, vertebral fractures, canal stenosis', icon: '🦴', slug: 'ct-spine' },
    ],
    processSteps: [
      { title: 'Book online', text: 'Choose your scan type, select a centre near you, and pick a date. No GP letter needed.' },
      { title: 'Short preparation', text: 'Some CT scans require fasting for 4 hours beforehand. We\'ll send full preparation instructions by email.' },
      { title: 'Quick scan', text: 'Most CT scans take just 10–20 minutes in the scanner. You\'ll be in and out in under an hour.' },
      { title: 'Report within 24 hours', text: 'Your radiologist\'s report is delivered to your secure portal the same day or next day.' },
    ],
    included: [
      'Full consultant radiologist\'s report',
      'High-resolution DICOM images',
      'Secure patient portal access',
      'Shareable report link',
    ],
    notes: [
      'CT scans use ionising radiation — your radiologist will confirm the scan is appropriate for your situation',
      'Contrast-enhanced CT available at most centres',
      'Low-dose protocols used wherever possible',
    ],
    aboutTitle: 'Private CT scanning — what you need to know',
    aboutBody: [
      'A CT (Computed Tomography) scan uses X-ray technology to produce detailed cross-sectional images of the body. CT is particularly useful for examining the chest, abdomen, and pelvis, and is often the fastest way to investigate acute symptoms.',
      'Unlike MRI, CT scans are quick (10–20 minutes) and suitable for patients who cannot tolerate the enclosed space of an MRI scanner. CT does involve a small amount of ionising radiation, so it is used when clinically appropriate.',
      'ScanBook connects you with 300+ CQC-registered CT imaging centres across the UK. All reports are delivered within 24 hours by a UK-based consultant radiologist.',
    ],
    faqs: [
      { q: 'Do I need a GP referral for a private CT scan?', a: 'No. You can self-refer and book directly through ScanBook without a GP letter.' },
      { q: 'How long does a CT scan take?', a: 'Most CT scans take 10–20 minutes in the scanner. The whole appointment is usually under an hour.' },
      { q: 'Is a CT scan safe?', a: 'CT scans use ionising radiation (X-rays). The dose is carefully controlled and modern scanners use the lowest dose necessary. If you are pregnant or may be pregnant, please inform the centre.' },
      { q: 'Do I need to fast before a CT scan?', a: 'Some CT scans (particularly abdominal and contrast-enhanced studies) require 4 hours of fasting beforehand. We\'ll send full instructions with your booking confirmation.' },
      { q: 'When will I receive my CT report?', a: 'All ScanBook partner centres deliver reports within 24 hours of your scan to your secure online portal.' },
    ],
    ctaTitle: 'Book your CT scan',
    ctaItalic: 'today.',
    ctaSub: 'No referral. Results in 24 hours. Centres nationwide.',
    related: ['mri-scan', 'ultrasound', 'x-ray'],
  },

  'ultrasound': {
    slug: 'ultrasound',
    title: 'Private Ultrasound Scans',
    titleItalic: 'quick and painless',
    category: 'DIAGNOSTIC SCANS',
    lead: 'Book a private ultrasound scan at accredited centres across the UK. No GP referral. Results and report same day or within 24 hours. Suitable for abdomen, pelvis, musculoskeletal, vascular, and more.',
    priceFrom: 99,
    priceSuffix: 'per scan',
    metaTitle: 'Private Ultrasound Scan UK | From £99 | Same Day Results | ScanBook',
    metaDescription: 'Book a private ultrasound scan at 500+ CQC-registered UK centres. No GP referral needed. Same-day or next-day report. Prices from £99.',
    trustItems: [
      { label: 'No referral', sub: 'self-refer online' },
      { label: '500+', sub: 'partner centres' },
      { label: 'Same day', sub: 'results available' },
      { label: 'From £99', sub: 'transparent pricing' },
    ],
    packages: [
      { label: 'ABDOMEN', price: 99 },
      { label: 'PELVIS', price: 99 },
      { label: 'THYROID', price: 115 },
      { label: 'BREAST', price: 125 },
      { label: 'MSK / JOINT', price: 115 },
    ],
    packageLabel: 'AREA',
    packageOptions: [
      'Abdominal Ultrasound — £99',
      'Pelvic Ultrasound — £99',
      'Thyroid Ultrasound — £115',
      'Breast Ultrasound — £125',
      'MSK / Joint — £115',
      'Vascular / Doppler — £135',
      'Renal Tract — £99',
    ],
    bodyPartGroups: [
      { group: 'Abdomen', items: ['Liver', 'Gallbladder', 'Kidneys', 'Pancreas', 'Aorta', 'Full Abdomen'] },
      { group: 'Pelvis', items: ['Pelvis (female)', 'Pelvis (male)', 'Bladder', 'Prostate (transabdominal)'] },
      { group: 'Soft Tissue', items: ['Thyroid', 'Breast', 'Lymph nodes', 'Salivary glands'] },
      { group: 'MSK and Vascular', items: ['Shoulder', 'Knee', 'Hip', 'Achilles', 'Carotid Doppler', 'DVT / Leg veins'] },
    ],
    bodyParts: [
      { name: 'Abdominal Ultrasound', desc: 'Liver, gallbladder, kidneys, pancreas, aorta', icon: '🫀', slug: 'abdominal-ultrasound' },
      { name: 'Pelvic Ultrasound', desc: 'Ovaries, uterus, bladder — female and male', icon: '⚕️', slug: 'pelvic-ultrasound' },
      { name: 'Thyroid Ultrasound', desc: 'Nodules, goitre, thyroid cancer screening', icon: '🔬', slug: 'thyroid-ultrasound' },
      { name: 'Breast Ultrasound', desc: 'Lumps, cysts, alongside mammogram', icon: '⚕️', slug: 'breast-ultrasound' },
      { name: 'MSK Ultrasound', desc: 'Tendons, muscles, joints, bursae', icon: '💪', slug: 'msk-ultrasound' },
      { name: 'Vascular Doppler', desc: 'DVT, carotid disease, peripheral vessels', icon: '❤️', slug: 'vascular-doppler' },
    ],
    processSteps: [
      { title: 'Book online', text: 'Select your area, choose a centre near you, and pick an appointment. No GP referral needed.' },
      { title: 'Short preparation', text: 'Abdominal scans require 4–6 hours of fasting. Pelvic scans need a full bladder. We\'ll send full instructions.' },
      { title: 'Quick, painless scan', text: 'Ultrasound uses high-frequency sound waves — no radiation. Most scans take 15–30 minutes.' },
      { title: 'Same-day or next-day results', text: 'Your sonographer may discuss findings immediately. A written radiologist\'s report follows within 24 hours.' },
    ],
    included: [
      'Trained sonographer',
      'Full consultant radiologist\'s report (within 24h)',
      'Digital images',
      'Secure online portal access',
    ],
    notes: [
      'No ionising radiation — safe for pregnant patients',
      'Abdominal ultrasound requires 4–6 hour fast',
      'Pelvic ultrasound requires a full bladder on arrival',
    ],
    aboutTitle: 'Private ultrasound in the UK',
    aboutBody: [
      'Ultrasound uses high-frequency sound waves to create real-time images of internal organs and soft tissue. It is the safest form of medical imaging — no radiation — and is used extensively for abdominal, pelvic, vascular, and musculoskeletal investigations.',
      'Private ultrasound through ScanBook gives you access to trained sonographers at 500+ CQC-registered centres. Results are available same day, with a full written radiologist\'s report within 24 hours.',
    ],
    faqs: [
      { q: 'Is an ultrasound scan safe?', a: 'Yes. Ultrasound uses sound waves, not radiation. It is safe for all patients including pregnant women.' },
      { q: 'Do I need to prepare for an ultrasound?', a: 'Preparation depends on the area being scanned. Abdominal scans typically require 4–6 hours without eating. Pelvic scans require a full bladder. We\'ll send specific instructions with your booking.' },
      { q: 'How quickly will I get my results?', a: 'Your sonographer may share initial findings during or immediately after the scan. A full written radiologist\'s report is delivered within 24 hours.' },
      { q: 'Can I book a breast ultrasound without a mammogram?', a: 'Yes. A standalone breast ultrasound is particularly useful for younger women or for investigating a specific lump or area of concern.' },
    ],
    ctaTitle: 'Book your ultrasound scan',
    ctaItalic: 'today.',
    ctaSub: 'No referral. Results same day or next day.',
    related: ['mri-scan', 'ct-scan', 'x-ray', 'baby-scan'],
  },

  'x-ray': {
    slug: 'x-ray',
    title: 'Private X-Ray',
    titleItalic: 'fast results, same day',
    category: 'DIAGNOSTIC SCANS',
    lead: 'Fast, affordable private X-Ray at accredited centres across the UK. No GP referral. In-and-out in under 30 minutes. Digital images and radiologist\'s report within 24 hours.',
    priceFrom: 75,
    priceSuffix: 'per X-Ray',
    metaTitle: 'Private X-Ray UK | From £75 | Same Day | ScanBook',
    metaDescription: 'Book a private X-Ray at CQC-registered centres across the UK. No GP referral needed. From £75. Results within 24 hours.',
    trustItems: [
      { label: 'No referral', sub: 'self-refer online' },
      { label: '500+', sub: 'partner centres' },
      { label: '15 min', sub: 'in the scanner' },
      { label: 'From £75', sub: 'lowest prices' },
    ],
    packages: [
      { label: 'SINGLE VIEW', price: 75 },
      { label: 'CHEST X-RAY', price: 75 },
      { label: 'JOINT X-RAY', price: 85 },
      { label: '2 VIEWS', price: 110 },
      { label: 'FULL SPINE', price: 199, featured: true },
    ],
    packageLabel: 'X-RAY TYPE',
    packageOptions: [
      'X-Ray — Single View — £75',
      'Chest X-Ray — £75',
      'Joint X-Ray — £85',
      'X-Ray — 2 Views — £110',
      'Full Spine X-Ray — £199',
    ],
    bodyPartGroups: [
      { group: 'Chest', items: ['Chest (PA)', 'Chest + Lateral'] },
      { group: 'Upper Limb', items: ['Hand', 'Wrist', 'Forearm', 'Elbow', 'Humerus', 'Shoulder'] },
      { group: 'Lower Limb', items: ['Foot', 'Ankle', 'Tibia/Fibula', 'Knee', 'Femur', 'Hip'] },
      { group: 'Spine and Pelvis', items: ['Cervical Spine', 'Thoracic Spine', 'Lumbar Spine', 'Sacrum/Coccyx', 'Pelvis'] },
    ],
    bodyParts: [
      { name: 'Chest X-Ray', desc: 'Infections, heart size, lung conditions', icon: '🫁', slug: 'chest-x-ray' },
      { name: 'Knee X-Ray', desc: 'Arthritis, fractures, joint space assessment', icon: '🦵', slug: 'knee-x-ray' },
      { name: 'Shoulder X-Ray', desc: 'Fractures, dislocations, arthritis', icon: '💪', slug: 'shoulder-x-ray' },
      { name: 'Spine X-Ray', desc: 'Posture assessment, vertebral fractures, arthritis', icon: '🦴', slug: 'spine-x-ray' },
      { name: 'Foot & Ankle', desc: 'Fractures, stress fractures, bone spurs', icon: '🦶', slug: 'foot-ankle-x-ray' },
      { name: 'Hand & Wrist', desc: 'Fractures, arthritis, joint assessment', icon: '🤝', slug: 'hand-wrist-x-ray' },
    ],
    processSteps: [
      { title: 'Book online in minutes', text: 'Choose your area, pick a centre near you, and select a time. No GP letter needed.' },
      { title: 'No special preparation', text: 'For most X-Rays, no fasting or preparation is required. Just arrive and check in.' },
      { title: 'In and out fast', text: 'The X-Ray itself takes 5–15 minutes. Most appointments are under 30 minutes total.' },
      { title: 'Report within 24 hours', text: 'Your digital images and radiologist\'s written report are in your secure portal within 24 hours.' },
    ],
    included: [
      'Digital X-Ray images (high resolution)',
      'Full consultant radiologist\'s report (within 24h)',
      'Secure patient portal access',
      'Shareable report link for your GP or consultant',
    ],
    notes: [
      'X-Rays involve a very small amount of ionising radiation',
      'Inform the centre if you are or may be pregnant',
      'Most X-Rays require no preparation — just arrive',
    ],
    aboutTitle: 'Private X-Ray in the UK',
    aboutBody: [
      'An X-Ray is the fastest and most affordable form of medical imaging. It uses a small amount of ionising radiation to produce images of dense structures — primarily bone — and is the first choice for investigating fractures, joint problems, chest conditions, and spinal issues.',
      'Through ScanBook, you can access digital X-Ray at 500+ CQC-registered centres across the UK. Same-day appointments are often available. Your radiologist\'s report is delivered within 24 hours.',
    ],
    faqs: [
      { q: 'Do I need a GP referral for a private X-Ray?', a: 'No. You can self-refer and book directly online through ScanBook without a GP letter.' },
      { q: 'How long does an X-Ray take?', a: 'The X-Ray itself takes 5–15 minutes. Most appointments are under 30 minutes.' },
      { q: 'Is an X-Ray safe?', a: 'Yes. An X-Ray uses a very small amount of ionising radiation — less than a transatlantic flight. If you are or may be pregnant, please inform the centre.' },
      { q: 'When will I get my report?', a: 'Digital images and a full radiologist\'s written report are delivered to your secure portal within 24 hours.' },
    ],
    ctaTitle: 'Book your X-Ray',
    ctaItalic: 'today.',
    ctaSub: 'No referral. Results within 24 hours. From £75.',
    related: ['mri-scan', 'ct-scan', 'ultrasound'],
  },
}

// ─── RELATED SCAN LABELS ──────────────────────────────────────────────────────

const RELATED_META: Record<string, { name: string; price: number; icon: string }> = {
  'mri-scan':   { name: 'MRI Scan',       price: 275, icon: '🧲' },
  'ct-scan':    { name: 'CT Scan',        price: 185, icon: '🔬' },
  'ultrasound': { name: 'Ultrasound',     price: 99,  icon: '🔊' },
  'x-ray':      { name: 'X-Ray',         price: 75,  icon: '🦴' },
  'baby-scan':  { name: 'Baby Scan',      price: 89,  icon: '👶' },
  'full-body-mri': { name: 'Full Body MRI', price: 1450, icon: '🫀' },
}

// ─── COMPONENTS ───────────────────────────────────────────────────────────────

function BookingWidget({ config }: { config: ScanConfig }) {
  const [selectedPkg, setSelectedPkg] = useState(config.packageOptions[0])
  const [selectedBodyPart, setSelectedBodyPart] = useState('')
  const [location, setLocation] = useState('')

  return (
    <div style={{ border: '1.5px solid #ebebeb', borderRadius: 16, padding: 26, position: 'sticky', top: 74, background: '#fff', boxShadow: '0 4px 32px rgba(0,0,0,.05)' }}>
      <div style={{ fontSize: 12, color: '#bbb', marginBottom: 2 }}>
        {config.title.split(' ')[1]} scan from
      </div>
      <div style={{ fontFamily: "'Instrument Serif', serif", fontSize: 40, color: '#111', letterSpacing: -1, lineHeight: 1, marginBottom: 22 }}>
        £{config.priceFrom} <span style={{ fontSize: 13, color: '#bbb', fontFamily: "'DM Sans', sans-serif", fontWeight: 400, letterSpacing: 0 }}>{config.priceSuffix}</span>
      </div>

      <div style={{ marginBottom: 12 }}>
        <label style={{ display: 'block', fontSize: 10, color: '#bbb', letterSpacing: 2, marginBottom: 5, fontWeight: 500 }}>{config.packageLabel}</label>
        <select
          value={selectedPkg}
          onChange={e => setSelectedPkg(e.target.value)}
          style={{ width: '100%', padding: '11px 13px', border: '1.5px solid #ebebeb', borderRadius: 8, fontSize: 14, fontFamily: 'inherit', color: '#111', background: '#fff', outline: 'none' }}
        >
          {config.packageOptions.map(o => <option key={o}>{o}</option>)}
        </select>
      </div>

      {config.bodyPartGroups.length > 0 && (
        <div style={{ marginBottom: 12 }}>
          <label style={{ display: 'block', fontSize: 10, color: '#bbb', letterSpacing: 2, marginBottom: 5, fontWeight: 500 }}>SELECT BODY PART</label>
          <select
            value={selectedBodyPart}
            onChange={e => setSelectedBodyPart(e.target.value)}
            style={{ width: '100%', padding: '11px 13px', border: '1.5px solid #ebebeb', borderRadius: 8, fontSize: 14, fontFamily: 'inherit', color: selectedBodyPart ? '#111' : '#ccc', background: '#fff', outline: 'none' }}
          >
            <option value="">Choose a body part…</option>
            {config.bodyPartGroups.map(g => (
              <optgroup key={g.group} label={g.group}>
                {g.items.map(item => <option key={item}>{item}</option>)}
              </optgroup>
            ))}
          </select>
        </div>
      )}

      <div style={{ marginBottom: 12 }}>
        <label style={{ display: 'block', fontSize: 10, color: '#bbb', letterSpacing: 2, marginBottom: 5, fontWeight: 500 }}>LOCATION</label>
        <input
          value={location}
          onChange={e => setLocation(e.target.value)}
          placeholder="Town or postcode"
          style={{ width: '100%', padding: '11px 13px', border: '1.5px solid #ebebeb', borderRadius: 8, fontSize: 14, fontFamily: 'inherit', color: '#111', background: '#fff', outline: 'none' }}
        />
      </div>

      <button
        style={{ width: '100%', padding: 14, border: 'none', borderRadius: 10, background: '#00C9A7', color: '#fff', fontSize: 14, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit', margin: '8px 0 14px' }}
        onMouseEnter={e => (e.currentTarget.style.opacity = '0.88')}
        onMouseLeave={e => (e.currentTarget.style.opacity = '1')}
      >
        Find Available Centres
      </button>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 6, paddingTop: 14, borderTop: '1px solid #f5f5f5' }}>
        {['CQC registered centres only', 'Secure payment via Stripe', 'Free cancellation up to 24 hours before'].map((g, i) => (
          <div key={i} style={{ fontSize: 11, color: '#aaa', display: 'flex', alignItems: 'center', gap: 7 }}>
            <span style={{ color: '#00C9A7', fontWeight: 700 }}>✓</span>{g}
          </div>
        ))}
      </div>
      <div style={{ textAlign: 'center', marginTop: 14, fontSize: 13, color: '#aaa' }}>
        or call us on <a href="tel:08001234567" style={{ color: '#111', textDecoration: 'none', fontWeight: 500 }}>0800 123 4567</a>
      </div>
    </div>
  )
}

function PriceCards({ packages }: { packages: PricePackage[] }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: `repeat(${packages.length}, 1fr)`, gap: 10, marginTop: 32 }}>
      {packages.map(pkg => (
        <div
          key={pkg.label}
          style={{ border: `1.5px solid ${pkg.featured ? '#111' : '#ebebeb'}`, borderRadius: 14, padding: '22px 16px', textAlign: 'center', cursor: 'pointer', transition: 'all .2s', background: pkg.featured ? '#111' : '#fff', position: 'relative' }}
          onMouseEnter={e => { if (!pkg.featured) { (e.currentTarget as HTMLDivElement).style.borderColor = '#00C9A7'; (e.currentTarget as HTMLDivElement).style.transform = 'translateY(-3px)'; (e.currentTarget as HTMLDivElement).style.boxShadow = '0 10px 32px rgba(0,201,167,.1)' } }}
          onMouseLeave={e => { if (!pkg.featured) { (e.currentTarget as HTMLDivElement).style.borderColor = '#ebebeb'; (e.currentTarget as HTMLDivElement).style.transform = ''; (e.currentTarget as HTMLDivElement).style.boxShadow = 'none' } }}
        >
          {pkg.featured && <div style={{ position: 'absolute', top: -9, left: '50%', transform: 'translateX(-50%)', background: '#00C9A7', color: '#fff', fontSize: 9, fontWeight: 700, letterSpacing: 1, padding: '3px 9px', borderRadius: 20, whiteSpace: 'nowrap' }}>BEST VALUE</div>}
          <div style={{ fontSize: 11, fontWeight: 600, color: pkg.featured ? 'rgba(255,255,255,.4)' : '#999', letterSpacing: 1, marginBottom: 14 }}>{pkg.label}</div>
          <div style={{ fontFamily: "'Instrument Serif', serif", fontSize: 34, color: pkg.featured ? '#fff' : '#111', letterSpacing: -1, marginBottom: 6 }}>£{pkg.price}</div>
          <div style={{ fontSize: 11, color: pkg.featured ? 'rgba(255,255,255,.3)' : '#bbb' }}>incl. report</div>
          <button
            style={{ marginTop: 16, width: '100%', padding: 9, border: pkg.featured ? 'none' : '1.5px solid #ebebeb', borderRadius: 8, background: pkg.featured ? '#00C9A7' : '#fff', color: pkg.featured ? '#fff' : '#222', fontSize: 12, fontWeight: 500, cursor: 'pointer', fontFamily: 'inherit', transition: 'all .15s' }}
            onMouseEnter={e => { if (!pkg.featured) { e.currentTarget.style.borderColor = '#00C9A7'; e.currentTarget.style.color = '#00a888' } }}
            onMouseLeave={e => { if (!pkg.featured) { e.currentTarget.style.borderColor = '#ebebeb'; e.currentTarget.style.color = '#222' } }}
          >
            Book this
          </button>
        </div>
      ))}
    </div>
  )
}

function FAQAccordion({ faqs }: { faqs: FAQ[] }) {
  const [openIdx, setOpenIdx] = useState<number | null>(null)
  return (
    <div style={{ borderRadius: 12, overflow: 'hidden', border: '1px solid #ebebeb', maxWidth: 700, marginTop: 28 }}>
      {faqs.map((faq, i) => (
        <div key={i} style={{ borderBottom: i < faqs.length - 1 ? '1px solid #ebebeb' : 'none', background: '#fff' }}>
          <div
            onClick={() => setOpenIdx(openIdx === i ? null : i)}
            style={{ padding: '17px 22px', fontSize: 14, fontWeight: 500, display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', gap: 16, color: '#111' }}
          >
            {faq.q}
            <span style={{ width: 22, height: 22, borderRadius: '50%', border: `1.5px solid ${openIdx === i ? 'transparent' : '#ddd'}`, display: 'grid', placeItems: 'center', flexShrink: 0, fontSize: 16, color: openIdx === i ? '#fff' : '#999', background: openIdx === i ? '#111' : 'transparent', transition: 'all .2s' }}>
              {openIdx === i ? '−' : '+'}
            </span>
          </div>
          {openIdx === i && (
            <div style={{ padding: '0 22px 17px', fontSize: 14, color: '#666', lineHeight: 1.75 }}>{faq.a}</div>
          )}
        </div>
      ))}
    </div>
  )
}

// ─── PAGE COMPONENT ───────────────────────────────────────────────────────────

interface PageProps {
  params: { scanType: string }
}

export default function ServicePage({ params }: PageProps) {
  // TODO Enes: real Next.js route param
  // For dev, default to mri-scan
  const config = SCAN_CONFIG[params?.scanType ?? 'mri-scan']

  if (!config) return <div>Scan type not found</div>

  return (
    <>
      <style>{`
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'DM Sans', sans-serif; background: #fff; color: #222; -webkit-font-smoothing: antialiased; }
      `}</style>

      {/* NAV */}
      <nav style={{ height: 60, padding: '0 48px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid #ebebeb', position: 'sticky', top: 0, background: '#fff', zIndex: 200 }}>
        <Link href="/" style={{ display: 'flex', alignItems: 'center', textDecoration: 'none' }}>
          <span style={{ fontFamily: "'Helvetica Neue', sans-serif", fontSize: 20, fontWeight: 700, color: '#111' }}>Scan</span>
          <span style={{ fontFamily: "'Helvetica Neue', sans-serif", fontSize: 20, fontWeight: 700, color: '#00C9A7' }}>Book</span>
        </Link>
        <div style={{ display: 'flex', gap: 4 }}>
          {['Services', 'About', 'How it works', 'Find a Centre', 'For Clinics', 'Blog', 'For Business'].map(l => (
            <a key={l} href="#" style={{ padding: '7px 13px', fontSize: 13, color: '#666', textDecoration: 'none', borderRadius: 7, transition: 'all .15s' }}>{l}</a>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button style={{ padding: '7px 16px', border: '1.5px solid #ebebeb', borderRadius: 7, background: '#fff', fontSize: 13, cursor: 'pointer', fontFamily: 'inherit' }}>Sign In</button>
          <button style={{ padding: '8px 18px', border: 'none', borderRadius: 7, background: '#00C9A7', color: '#fff', fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>Book a Scan</button>
        </div>
      </nav>

      {/* BREADCRUMB */}
      <div style={{ padding: '12px 48px', fontSize: 12, color: '#bbb', borderBottom: '1px solid #f5f5f5' }}>
        <Link href="/" style={{ color: '#999', textDecoration: 'none' }}>Home</Link> /{' '}
        <Link href="/services" style={{ color: '#999', textDecoration: 'none' }}>Services</Link> /{' '}
        <span style={{ color: '#444' }}>{config.title}</span>
      </div>

      {/* HERO */}
      <div style={{ maxWidth: 1180, margin: '0 auto', padding: '60px 48px 0', display: 'grid', gridTemplateColumns: '1fr 370px', gap: 72, alignItems: 'start' }}>
        <div>
          <div style={{ fontSize: 11, letterSpacing: 2.5, color: '#bbb', marginBottom: 14, fontWeight: 500 }}>{config.category}</div>
          <h1 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 46, lineHeight: 1.1, letterSpacing: -1.5, color: '#111', marginBottom: 18 }}>
            {config.title}<br /><em style={{ fontStyle: 'italic', color: '#00C9A7' }}>{config.titleItalic}</em>
          </h1>
          <p style={{ fontSize: 16, color: '#666', lineHeight: 1.85, marginBottom: 32, maxWidth: 490 }}>{config.lead}</p>

          {/* Trust strip */}
          <div style={{ display: 'flex', border: '1px solid #ebebeb', borderRadius: 10, overflow: 'hidden', marginBottom: 36 }}>
            {config.trustItems.map((item, i) => (
              <div key={i} style={{ flex: 1, padding: '12px 10px', textAlign: 'center', borderRight: i < config.trustItems.length - 1 ? '1px solid #ebebeb' : 'none', fontSize: 11, color: '#999', lineHeight: 1.4 }}>
                <strong style={{ display: 'block', fontSize: 14, color: '#111', fontWeight: 600, marginBottom: 2 }}>{item.label}</strong>
                {item.sub}
              </div>
            ))}
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 9, fontSize: 13, color: '#666' }}>
            <span style={{ color: '#00b67a', fontSize: 13, letterSpacing: 1 }}>★★★★★</span>
            <span><strong>Excellent</strong> on Trustpilot &nbsp;·&nbsp; 4.9 from 2,400 reviews</span>
          </div>
        </div>

        <BookingWidget config={config} />
      </div>

      {/* PRICING */}
      <div style={{ height: 1, background: '#ebebeb', margin: '56px 48px 0' }} />
      <div style={{ maxWidth: 1180, margin: '0 auto', padding: '60px 48px' }}>
        <div style={{ fontSize: 10, letterSpacing: 3, color: '#bbb', marginBottom: 12, fontWeight: 500 }}>TRANSPARENT PRICING</div>
        <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 34, letterSpacing: -0.8, marginBottom: 16, color: '#111' }}>
          Simple, fixed pricing.<br /><em style={{ fontStyle: 'italic', color: '#00C9A7' }}>No hidden fees.</em>
        </h2>
        <p style={{ fontSize: 15, color: '#666', maxWidth: 520 }}>All prices include the scan, a full written radiologist's report, and your digital images.</p>
        <PriceCards packages={config.packages} />
        {config.teslaNote && (
          <div style={{ marginTop: 24, padding: '18px 20px', background: '#f8f8f8', border: '1px solid #ebebeb', borderRadius: 12, fontSize: 13, color: '#555', lineHeight: 1.7, maxWidth: 700 }}>
            <strong style={{ color: '#111', fontWeight: 500 }}>About scanner quality (1.5T vs 3T):</strong> {config.teslaNote}
          </div>
        )}
      </div>

      {/* BODY PARTS */}
      <div style={{ background: '#f8f8f8', padding: '60px 48px' }}>
        <div style={{ maxWidth: 1180, margin: '0 auto' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 26 }}>
            <div>
              <div style={{ fontSize: 10, letterSpacing: 3, color: '#bbb', marginBottom: 12, fontWeight: 500 }}>SCAN BY AREA</div>
              <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 34, letterSpacing: -0.8, color: '#111' }}>What area do you need scanned?</h2>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 9 }}>
            {config.bodyParts.map(bp => (
              <Link
                key={bp.slug}
                href={`/body-parts/${bp.slug}`}
                style={{ border: '1px solid #ebebeb', borderRadius: 12, padding: 15, cursor: 'pointer', transition: 'all .18s', background: '#fff', display: 'flex', flexDirection: 'column', gap: 7, textDecoration: 'none' }}
                onMouseEnter={e => { (e.currentTarget as HTMLAnchorElement).style.borderColor = '#00C9A7'; (e.currentTarget as HTMLAnchorElement).style.boxShadow = '0 4px 18px rgba(0,201,167,.1)'; (e.currentTarget as HTMLAnchorElement).style.transform = 'translateY(-1px)' }}
                onMouseLeave={e => { (e.currentTarget as HTMLAnchorElement).style.borderColor = '#ebebeb'; (e.currentTarget as HTMLAnchorElement).style.boxShadow = 'none'; (e.currentTarget as HTMLAnchorElement).style.transform = '' }}
              >
                <div style={{ width: 34, height: 34, borderRadius: 8, background: '#f8f8f8', display: 'grid', placeItems: 'center', fontSize: 18 }}>{bp.icon}</div>
                <div style={{ fontSize: 13, fontWeight: 500, color: '#111' }}>{bp.name}</div>
                <div style={{ fontSize: 11, color: '#aaa', lineHeight: 1.5 }}>{bp.desc}</div>
                <div style={{ fontSize: 12, color: '#bbb', marginTop: 4 }}>View →</div>
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* WHAT TO EXPECT */}
      <div style={{ maxWidth: 1180, margin: '0 auto', padding: '60px 48px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 72 }}>
          <div>
            <div style={{ fontSize: 10, letterSpacing: 3, color: '#bbb', marginBottom: 12, fontWeight: 500 }}>WHAT TO EXPECT</div>
            <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 34, letterSpacing: -0.8, marginBottom: 24, color: '#111' }}>How it works</h2>
            <div style={{ display: 'flex', flexDirection: 'column' }}>
              {config.processSteps.map((step, i) => (
                <div key={i} style={{ display: 'flex', gap: 22, paddingBottom: 28 }}>
                  <div style={{ width: 30, height: 30, borderRadius: '50%', border: '1.5px solid #ebebeb', display: 'grid', placeItems: 'center', fontSize: 12, fontWeight: 600, color: '#666', flexShrink: 0, background: '#fff', position: 'relative', zIndex: 1 }}>
                    {i + 1}
                    {i < config.processSteps.length - 1 && <span style={{ position: 'absolute', top: 30, left: '50%', transform: 'translateX(-50%)', width: 1, height: 'calc(100% + 4px)', background: '#ebebeb' }} />}
                  </div>
                  <div style={{ paddingTop: 3 }}>
                    <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 5, color: '#111' }}>{step.title}</div>
                    <div style={{ fontSize: 14, color: '#666', lineHeight: 1.75 }}>{step.text}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div>
            <div style={{ fontSize: 10, letterSpacing: 3, color: '#bbb', marginBottom: 12, fontWeight: 500 }}>WHAT'S INCLUDED</div>
            <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 34, letterSpacing: -0.8, marginBottom: 24, color: '#111' }}>Everything included<br /><em style={{ fontStyle: 'italic', color: '#00C9A7' }}>in every scan.</em></h2>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18 }}>
              <div style={{ borderRadius: 14, padding: 24, background: '#f0fdf8', border: '1px solid #c6f0e5' }}>
                <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 16, display: 'flex', alignItems: 'center', gap: 8, color: '#111' }}>
                  <span style={{ color: '#00a888' }}>✓</span> Always included
                </div>
                {config.included.map((item, i) => (
                  <div key={i} style={{ fontSize: 13, color: '#444', display: 'flex', alignItems: 'flex-start', gap: 10, lineHeight: 1.55, marginBottom: i < config.included.length - 1 ? 9 : 0 }}>
                    <span style={{ width: 17, height: 17, borderRadius: '50%', background: '#00C9A7', display: 'grid', placeItems: 'center', flexShrink: 0, marginTop: 1, fontSize: 9, color: '#fff', fontWeight: 700 }}>✓</span>
                    {item}
                  </div>
                ))}
              </div>
              <div style={{ borderRadius: 14, padding: 24, background: '#f8f8f8', border: '1px solid #ebebeb' }}>
                <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 16, display: 'flex', alignItems: 'center', gap: 8, color: '#111' }}>
                  ℹ Notes
                </div>
                {config.notes.map((note, i) => (
                  <div key={i} style={{ fontSize: 13, color: '#666', display: 'flex', alignItems: 'flex-start', gap: 10, lineHeight: 1.55, marginBottom: i < config.notes.length - 1 ? 9 : 0 }}>
                    <span style={{ width: 17, height: 17, borderRadius: '50%', background: '#f5a623', display: 'grid', placeItems: 'center', flexShrink: 0, marginTop: 1, fontSize: 9, color: '#fff', fontWeight: 700 }}>i</span>
                    {note}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ABOUT */}
      <div style={{ background: '#f8f8f8', padding: '60px 48px' }}>
        <div style={{ maxWidth: 1180, margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 72 }}>
          <div>
            <div style={{ fontSize: 10, letterSpacing: 3, color: '#bbb', marginBottom: 12, fontWeight: 500 }}>CLINICAL INFORMATION</div>
            <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 34, letterSpacing: -0.8, marginBottom: 24, color: '#111' }}>{config.aboutTitle}</h2>
            {config.aboutBody.map((p, i) => (
              <p key={i} style={{ fontSize: 15, color: '#555', lineHeight: 1.85, marginBottom: 14 }}>{p}</p>
            ))}
          </div>
          <div>
            <div style={{ fontSize: 10, letterSpacing: 3, color: '#bbb', marginBottom: 12, fontWeight: 500 }}>FAQ</div>
            <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 34, letterSpacing: -0.8, marginBottom: 8, color: '#111' }}>Common questions</h2>
            <FAQAccordion faqs={config.faqs} />
          </div>
        </div>
      </div>

      {/* RELATED */}
      <div style={{ maxWidth: 1180, margin: '0 auto', padding: '60px 48px' }}>
        <div style={{ fontSize: 10, letterSpacing: 3, color: '#bbb', marginBottom: 12, fontWeight: 500 }}>OTHER SCANS</div>
        <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 34, letterSpacing: -0.8, marginBottom: 28, color: '#111' }}>Related services</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
          {config.related.map(slug => {
            const meta = RELATED_META[slug]
            if (!meta) return null
            return (
              <Link key={slug} href={`/services/${slug}`} style={{ border: '1px solid #ebebeb', borderRadius: 12, padding: 20, cursor: 'pointer', transition: 'all .2s', textDecoration: 'none', display: 'block', background: '#fff' }}
                onMouseEnter={e => { (e.currentTarget as HTMLAnchorElement).style.borderColor = '#111'; (e.currentTarget as HTMLAnchorElement).style.transform = 'translateY(-2px)' }}
                onMouseLeave={e => { (e.currentTarget as HTMLAnchorElement).style.borderColor = '#ebebeb'; (e.currentTarget as HTMLAnchorElement).style.transform = '' }}
              >
                <div style={{ width: 38, height: 38, borderRadius: 9, background: '#f8f8f8', display: 'grid', placeItems: 'center', marginBottom: 12, fontSize: 20 }}>{meta.icon}</div>
                <div style={{ fontSize: 14, fontWeight: 500, color: '#111', marginBottom: 3 }}>{meta.name}</div>
                <div style={{ fontSize: 12, color: '#aaa', marginBottom: 8 }}>From £{meta.price}</div>
                <div style={{ fontSize: 12, color: '#bbb' }}>View →</div>
              </Link>
            )
          })}
        </div>
      </div>

      {/* CTA */}
      <div style={{ background: '#111', padding: '72px 48px', textAlign: 'center' }}>
        <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 40, color: '#fff', marginBottom: 12, letterSpacing: -0.8 }}>
          {config.ctaTitle} <em style={{ color: '#00C9A7', fontStyle: 'italic' }}>{config.ctaItalic}</em>
        </h2>
        <p style={{ fontSize: 15, color: 'rgba(255,255,255,.45)', marginBottom: 32 }}>{config.ctaSub}</p>
        <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
          <button style={{ padding: '14px 28px', border: 'none', borderRadius: 9, background: '#00C9A7', color: '#fff', fontSize: 14, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>
            Find a Centre
          </button>
          <button style={{ padding: '14px 22px', border: '1px solid rgba(255,255,255,.2)', borderRadius: 9, background: 'transparent', color: 'rgba(255,255,255,.65)', fontSize: 14, cursor: 'pointer', fontFamily: 'inherit' }}>
            Call 0800 123 4567
          </button>
        </div>
      </div>

      {/* FOOTER */}
      <footer style={{ background: '#111', borderTop: '1px solid rgba(255,255,255,.06)', padding: '24px 48px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span style={{ fontFamily: "'Helvetica Neue', sans-serif", fontSize: 16, fontWeight: 700 }}>
          <span style={{ color: '#fff' }}>Scan</span><span style={{ color: '#00C9A7' }}>Book</span>
        </span>
        <span style={{ fontSize: 11, color: 'rgba(255,255,255,.2)' }}>© 2025 The Connective UK Ltd · CQC Partner Network · Registered in England and Wales</span>
        <div style={{ display: 'flex', gap: 20 }}>
          {['Privacy', 'Terms', 'Cookies', 'Sitemap'].map(l => (
            <a key={l} href="#" style={{ fontSize: 12, color: 'rgba(255,255,255,.3)', textDecoration: 'none' }}>{l}</a>
          ))}
        </div>
      </footer>
    </>
  )
}
