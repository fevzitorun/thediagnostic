'use client'

// app/how-it-works/page.tsx

import Link from 'next/link'
import { useState } from 'react'
import { Header, Footer, Breadcrumb } from '@/components/layout'

const STEPS = [
  {
    num: '01',
    title: 'Choose your scan',
    body: 'Select your scan type — MRI, CT, ultrasound, X-Ray, or baby scan. Then choose your body part or area. No GP letter needed at any stage.',
    detail: [
      'Search by scan type, body part, or symptom',
      'Filter by location, price, scanner quality (1.5T / 3T), and availability',
      'Compare centres side by side — ratings, prices, next available slot',
    ],
    icon: '🔍',
    color: '#e6faf7',
    accent: '#00C9A7',
  },
  {
    num: '02',
    title: 'Book & pay securely',
    body: 'Pick a date and time that works for you. Pay securely via Stripe. You\'ll receive an instant booking confirmation and preparation instructions by email.',
    detail: [
      'Appointments often available within 48 hours',
      'Secure payment via Stripe — card or Apple/Google Pay',
      'Free cancellation up to 24 hours before your appointment',
      'SMS and email reminders sent automatically',
    ],
    icon: '📅',
    color: '#eff6ff',
    accent: '#3b82f6',
  },
  {
    num: '03',
    title: 'Attend your scan',
    body: 'Arrive at your chosen CQC-registered imaging centre. Your radiographer will guide you through the scan. Most appointments are 30–60 minutes.',
    detail: [
      'All centres are CQC registered and accredited',
      'Bring your booking confirmation (email or phone)',
      'Radiographer explains the process before you start',
      'Changing facilities, lockers, and refreshments available',
    ],
    icon: '🏥',
    color: '#fef9ee',
    accent: '#f59e0b',
  },
  {
    num: '04',
    title: 'Receive your report',
    body: 'A UK-based consultant radiologist reviews your images and writes a full clinical report. Delivered to your secure online portal within 24–48 hours.',
    detail: [
      'Full written report by a UK consultant radiologist',
      'High-resolution digital images in DICOM format',
      'Secure shareable link for your GP or consultant',
      'Access your portal anytime on mobile or desktop',
    ],
    icon: '📋',
    color: '#f0fdf8',
    accent: '#00C9A7',
  },
]

const FAQS = [
  {
    q: 'Do I need a GP referral or letter?',
    a: 'No. You can self-refer and book directly through ScanBook without any letter, referral, or prior appointment. Simply choose your scan, select a centre, and book.',
  },
  {
    q: 'How quickly can I get an appointment?',
    a: 'Many of our partner centres have availability within 24–48 hours. Use the date filter on the search page to find the earliest available slot near you.',
  },
  {
    q: 'Who reports my scan?',
    a: 'All scans are reported by a UK-qualified consultant radiologist — a doctor who specialises in interpreting medical imaging. You receive a full written clinical report, not just images.',
  },
  {
    q: 'Can I share my report with my GP?',
    a: 'Yes. Your secure patient portal generates a shareable link you can send to any doctor, consultant, or specialist. You can also download a PDF or request a printed copy.',
  },
  {
    q: 'What if I need to cancel or reschedule?',
    a: 'Free cancellation is available up to 24 hours before your appointment. To reschedule, log into your portal or contact the centre directly. Cancellations within 24 hours may incur a fee.',
  },
  {
    q: 'Is my payment secure?',
    a: 'Yes. All payments are processed by Stripe, which is PCI-DSS compliant. ScanBook never stores your card details. We accept all major cards, Apple Pay, and Google Pay.',
  },
  {
    q: 'Can I use health insurance?',
    a: 'Yes. We accept Bupa, AXA Health, Aviva, Vitality, WPA, and Cigna at most partner centres. Contact your insurer first to confirm coverage and obtain a pre-authorisation number, then select "Pay by insurance" at checkout.',
  },
  {
    q: 'What happens if something is found?',
    a: 'Your radiologist\'s report will describe any findings clearly. If something requires urgent attention, the reporting radiologist will contact you directly. We recommend sharing your report with your GP or a specialist for clinical advice.',
  },
]

const TRUST_ITEMS = [
  { icon: '🏥', title: '600+ CQC centres', body: 'Every partner centre is CQC registered. We verify accreditation before any centre joins the network.' },
  { icon: '👨‍⚕️', title: 'UK consultant radiologists', body: 'All reports are written by UK-qualified consultant radiologists — not overseas reporters, not AI summaries.' },
  { icon: '🔒', title: 'GDPR compliant', body: 'Your health data is processed in line with UK GDPR and ICO guidelines. We never sell your data.' },
  { icon: '💳', title: 'Stripe payments', body: 'Payments handled by Stripe — PCI-DSS certified, never stored on our servers.' },
]

export default function HowItWorksPage() {
  const [openFaq, setOpenFaq] = useState<number | null>(null)

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'DM Sans', sans-serif; background: #fff; color: #222; -webkit-font-smoothing: antialiased; }
      `}</style>

      <Header />
      <Breadcrumb items={[{ label: 'Home', href: '/' }, { label: 'How it works' }]} />

      {/* HERO */}
      <div style={{ maxWidth: 1180, margin: '0 auto', padding: '64px 48px 0' }}>
        <div style={{ maxWidth: 580 }}>
          <div style={{ fontSize: 10, letterSpacing: 3, color: '#bbb', fontWeight: 500, marginBottom: 14, textTransform: 'uppercase' }}>Simple process</div>
          <h1 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 52, lineHeight: 1.08, letterSpacing: -1.8, color: '#111', marginBottom: 18 }}>
            From search to report<br /><em style={{ fontStyle: 'italic', color: '#00C9A7' }}>in four steps.</em>
          </h1>
          <p style={{ fontSize: 16, color: '#666', lineHeight: 1.8, marginBottom: 36 }}>
            ScanBook connects you with CQC-registered private imaging centres across the UK. No GP referral, no waiting lists. Book online in minutes and receive a full radiologist's report within 24–48 hours.
          </p>
          <Link href="/search" style={{ display: 'inline-block', padding: '13px 26px', background: '#111', color: '#fff', borderRadius: 9, fontSize: 14, fontWeight: 600, textDecoration: 'none', transition: 'background .15s' }}
            onMouseEnter={e => (e.currentTarget.style.background = '#00C9A7')}
            onMouseLeave={e => (e.currentTarget.style.background = '#111')}
          >
            Find a scan →
          </Link>
        </div>
      </div>

      {/* STEPS */}
      <div style={{ maxWidth: 1180, margin: '0 auto', padding: '64px 48px' }}>
        {STEPS.map((step, i) => (
          <div key={i}>
            <div style={{ display: 'grid', gridTemplateColumns: i % 2 === 0 ? '1fr 1fr' : '1fr 1fr', gap: 80, alignItems: 'center', marginBottom: i < STEPS.length - 1 ? 80 : 0 }}>

              {/* Text side */}
              <div style={{ order: i % 2 === 0 ? 0 : 1 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 20 }}>
                  <span style={{ fontFamily: "'Instrument Serif', serif", fontSize: 56, color: '#f0f0f0', letterSpacing: -2, lineHeight: 1 }}>{step.num}</span>
                  <div style={{ width: 48, height: 48, borderRadius: 14, background: step.color, display: 'grid', placeItems: 'center', fontSize: 24 }}>{step.icon}</div>
                </div>
                <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 34, letterSpacing: -0.8, color: '#111', marginBottom: 14, lineHeight: 1.2 }}>
                  {step.title}
                </h2>
                <p style={{ fontSize: 15, color: '#666', lineHeight: 1.8, marginBottom: 20 }}>{step.body}</p>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
                  {step.detail.map((d, j) => (
                    <div key={j} style={{ display: 'flex', gap: 10, fontSize: 13, color: '#555', alignItems: 'flex-start' }}>
                      <span style={{ color: step.accent, fontWeight: 700, flexShrink: 0, marginTop: 1 }}>✓</span>
                      {d}
                    </div>
                  ))}
                </div>
              </div>

              {/* Visual side */}
              <div style={{ order: i % 2 === 0 ? 1 : 0 }}>
                <div style={{ background: step.color, borderRadius: 20, padding: '40px 36px', border: `1px solid ${step.accent}22` }}>
                  {i === 0 && <SearchVisual />}
                  {i === 1 && <BookingVisual />}
                  {i === 2 && <AppointmentVisual />}
                  {i === 3 && <ReportVisual />}
                </div>
              </div>

            </div>

            {/* Connector line */}
            {i < STEPS.length - 1 && (
              <div style={{ display: 'flex', justifyContent: 'center', margin: '0 0 80px' }}>
                <div style={{ width: 1, height: 60, background: 'linear-gradient(to bottom, #ebebeb, transparent)' }} />
              </div>
            )}
          </div>
        ))}
      </div>

      {/* TRUST */}
      <div style={{ background: '#f8f8f8', borderTop: '1px solid #ebebeb', padding: '64px 48px' }}>
        <div style={{ maxWidth: 1180, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 44 }}>
            <div style={{ fontSize: 10, letterSpacing: 3, color: '#bbb', fontWeight: 500, marginBottom: 12, textTransform: 'uppercase' }}>Why patients trust us</div>
            <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 36, letterSpacing: -0.8, color: '#111' }}>
              Safe, accredited, and secure.
            </h2>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 20 }}>
            {TRUST_ITEMS.map((item, i) => (
              <div key={i} style={{ background: '#fff', border: '1px solid #ebebeb', borderRadius: 16, padding: '24px 20px' }}>
                <div style={{ fontSize: 28, marginBottom: 14 }}>{item.icon}</div>
                <div style={{ fontSize: 14, fontWeight: 600, color: '#111', marginBottom: 8 }}>{item.title}</div>
                <div style={{ fontSize: 13, color: '#888', lineHeight: 1.65 }}>{item.body}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* FAQ */}
      <div style={{ maxWidth: 1180, margin: '0 auto', padding: '64px 48px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 80 }}>
          <div>
            <div style={{ fontSize: 10, letterSpacing: 3, color: '#bbb', fontWeight: 500, marginBottom: 12, textTransform: 'uppercase' }}>FAQ</div>
            <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 34, letterSpacing: -0.8, color: '#111', marginBottom: 16, lineHeight: 1.2 }}>
              Common questions
            </h2>
            <p style={{ fontSize: 14, color: '#888', lineHeight: 1.7, marginBottom: 24 }}>
              Can't find what you're looking for? Our team is happy to help.
            </p>
            <a href="tel:08001234567" style={{ display: 'inline-block', padding: '10px 18px', border: '1.5px solid #ebebeb', borderRadius: 9, fontSize: 13, color: '#111', textDecoration: 'none', fontWeight: 500 }}>
              Call 0800 123 4567
            </a>
          </div>
          <div>
            <div style={{ border: '1px solid #ebebeb', borderRadius: 14, overflow: 'hidden' }}>
              {FAQS.map((faq, i) => (
                <div key={i} style={{ borderBottom: i < FAQS.length - 1 ? '1px solid #ebebeb' : 'none', background: '#fff' }}>
                  <div
                    onClick={() => setOpenFaq(openFaq === i ? null : i)}
                    style={{ padding: '17px 22px', fontSize: 14, fontWeight: 500, display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', gap: 16, color: '#111' }}
                  >
                    {faq.q}
                    <span style={{ width: 22, height: 22, borderRadius: '50%', border: `1.5px solid ${openFaq === i ? 'transparent' : '#ddd'}`, display: 'grid', placeItems: 'center', flexShrink: 0, fontSize: 16, color: openFaq === i ? '#fff' : '#999', background: openFaq === i ? '#111' : 'transparent', transition: 'all .2s' }}>
                      {openFaq === i ? '−' : '+'}
                    </span>
                  </div>
                  {openFaq === i && (
                    <div style={{ padding: '0 22px 17px', fontSize: 14, color: '#666', lineHeight: 1.75 }}>{faq.a}</div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* CTA */}
      <section style={{ background: '#111', padding: '72px 48px', textAlign: 'center' }}>
        <div style={{ maxWidth: 520, margin: '0 auto' }}>
          <h2 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 40, color: '#fff', marginBottom: 12, letterSpacing: -1, lineHeight: 1.15 }}>
            Ready to get started?
          </h2>
          <p style={{ fontSize: 14, color: 'rgba(255,255,255,.4)', marginBottom: 32 }}>
            Find a centre near you. Book in minutes. Report in 24–48 hours.
          </p>
          <Link href="/search" style={{ display: 'inline-block', padding: '14px 32px', background: '#00C9A7', color: '#fff', borderRadius: 10, fontSize: 15, fontWeight: 600, textDecoration: 'none' }}>
            Find a scan →
          </Link>
        </div>
      </section>

      <Footer />
    </>
  )
}

// ─── STEP VISUALS ─────────────────────────────────────────────────────────────

function SearchVisual() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      <div style={{ background: '#fff', borderRadius: 12, padding: '14px 16px', border: '1px solid #d1fae5', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div style={{ fontSize: 10, color: '#bbb', fontWeight: 600, letterSpacing: 1.5, marginBottom: 3, textTransform: 'uppercase' }}>Scan type</div>
          <div style={{ fontSize: 14, fontWeight: 500, color: '#111' }}>MRI Scan</div>
        </div>
        <span style={{ fontSize: 18 }}>🧲</span>
      </div>
      <div style={{ background: '#fff', borderRadius: 12, padding: '14px 16px', border: '1px solid #ebebeb', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div style={{ fontSize: 10, color: '#bbb', fontWeight: 600, letterSpacing: 1.5, marginBottom: 3, textTransform: 'uppercase' }}>Body part</div>
          <div style={{ fontSize: 14, fontWeight: 500, color: '#111' }}>Knee</div>
        </div>
        <span style={{ fontSize: 18 }}>🦵</span>
      </div>
      <div style={{ background: '#fff', borderRadius: 12, padding: '14px 16px', border: '1px solid #ebebeb', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div style={{ fontSize: 10, color: '#bbb', fontWeight: 600, letterSpacing: 1.5, marginBottom: 3, textTransform: 'uppercase' }}>Location</div>
          <div style={{ fontSize: 14, fontWeight: 500, color: '#111' }}>London</div>
        </div>
        <span style={{ fontSize: 18 }}>📍</span>
      </div>
      <div style={{ background: '#111', borderRadius: 10, padding: '12px 16px', textAlign: 'center', fontSize: 14, fontWeight: 600, color: '#fff', marginTop: 4 }}>
        Find available centres →
      </div>
    </div>
  )
}

function BookingVisual() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      <div style={{ background: '#fff', borderRadius: 12, padding: '16px', border: '1px solid #ebebeb' }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: '#111', marginBottom: 10 }}>Harley Street Imaging</div>
        <div style={{ display: 'flex', gap: 6, marginBottom: 12 }}>
          {['Mon', 'Tue', 'Wed', 'Thu', 'Fri'].map((d, i) => (
            <div key={d} style={{ flex: 1, padding: '7px 4px', textAlign: 'center', borderRadius: 8, background: i === 1 ? '#111' : '#f8f8f8', border: `1px solid ${i === 1 ? '#111' : '#ebebeb'}` }}>
              <div style={{ fontSize: 9, color: i === 1 ? 'rgba(255,255,255,.6)' : '#bbb', fontWeight: 600 }}>{d}</div>
              <div style={{ fontSize: 11, color: i === 1 ? '#fff' : '#444', fontWeight: i === 1 ? 600 : 400, marginTop: 2 }}>
                {['14', '15', '16', '17', '18'][i]}
              </div>
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderTop: '1px solid #f5f5f5', fontSize: 13 }}>
          <span style={{ color: '#666' }}>MRI — 1 Body Part</span>
          <span style={{ fontWeight: 600, color: '#111' }}>£275</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderTop: '1px solid #f5f5f5', fontSize: 13 }}>
          <span style={{ color: '#666' }}>Radiologist report</span>
          <span style={{ color: '#00a888', fontWeight: 500 }}>Included</span>
        </div>
      </div>
      <div style={{ background: '#00C9A7', borderRadius: 10, padding: '12px 16px', textAlign: 'center', fontSize: 14, fontWeight: 600, color: '#fff' }}>
        Pay securely · £275
      </div>
      <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
        {['🔒 Stripe', '✓ Free cancellation', '📧 Instant confirmation'].map((t, i) => (
          <span key={i} style={{ fontSize: 10, color: '#888', display: 'flex', alignItems: 'center', gap: 3 }}>{t}</span>
        ))}
      </div>
    </div>
  )
}

function AppointmentVisual() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div style={{ background: '#fff', borderRadius: 12, padding: '16px', border: '1px solid #ebebeb' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
          <div style={{ width: 40, height: 40, borderRadius: 10, background: '#e6faf7', display: 'grid', placeItems: 'center', fontSize: 20 }}>🏥</div>
          <div>
            <div style={{ fontSize: 13, fontWeight: 600, color: '#111' }}>Harley Street Imaging</div>
            <div style={{ fontSize: 11, color: '#888' }}>Tue 15 May · 10:30am</div>
          </div>
          <span style={{ marginLeft: 'auto', fontSize: 10, padding: '3px 8px', borderRadius: 20, background: '#e6faf7', color: '#00a888', fontWeight: 600 }}>Confirmed</span>
        </div>
        {[
          { icon: '📋', text: 'Bring your booking confirmation' },
          { icon: '⏱', text: 'Allow 45 minutes total' },
          { icon: '🧲', text: 'Remove metal jewellery beforehand' },
          { icon: '🅿️', text: 'Free parking on-site' },
        ].map((item, i) => (
          <div key={i} style={{ display: 'flex', gap: 9, fontSize: 12, color: '#666', alignItems: 'center', padding: '7px 0', borderTop: '1px solid #f5f5f5' }}>
            <span>{item.icon}</span>{item.text}
          </div>
        ))}
      </div>
    </div>
  )
}

function ReportVisual() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      <div style={{ background: '#fff', borderRadius: 12, padding: '18px', border: '1px solid #d1fae5' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
          <div>
            <div style={{ fontSize: 11, color: '#00a888', fontWeight: 600, marginBottom: 2 }}>RADIOLOGY REPORT</div>
            <div style={{ fontSize: 13, fontWeight: 600, color: '#111' }}>Right Knee MRI</div>
            <div style={{ fontSize: 11, color: '#bbb', marginTop: 2 }}>Dr. S. Patel, Consultant Radiologist</div>
          </div>
          <span style={{ fontSize: 10, padding: '3px 8px', borderRadius: 20, background: '#e6faf7', color: '#00a888', fontWeight: 600 }}>✓ Delivered 24h</span>
        </div>
        <div style={{ fontSize: 12, color: '#555', lineHeight: 1.65, background: '#f8f8f8', borderRadius: 8, padding: '10px 12px', fontFamily: 'serif' }}>
          "No evidence of significant ligamentous injury. Mild medial compartment cartilage thinning consistent with early degenerative change. Menisci intact…"
        </div>
        <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
          {['📄 Download PDF', '🔗 Share with GP', '🖼 View images'].map((a, i) => (
            <div key={i} style={{ fontSize: 10, padding: '5px 9px', borderRadius: 7, border: '1px solid #ebebeb', color: '#666', background: '#fff', cursor: 'pointer', whiteSpace: 'nowrap' }}>
              {a}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
