'use client'

// app/centres/page.tsx
//
// TODO Enes:
//   - Replace MOCK_CLINICS with prisma.clinic.findMany() — server component veya API route
//   - Map placeholder → Google Maps embed veya Mapbox GL
//   - Location search → postcodes.io autocomplete (ücretsiz UK API)
//   - URL params: /centres?city=london&type=mri&tesla=3t

import Link from 'next/link'
import { useState, useMemo } from 'react'
import { Header, Footer, Breadcrumb } from '@/components/layout'

// ─── TYPES ────────────────────────────────────────────────────────────────────

interface Clinic {
  id: string
  slug: string
  name: string
  city: string
  region: string
  address: string
  postcode: string
  distanceMiles?: number
  rating: number
  reviewCount: number
  tesla: '1.5T' | '2T' | '3T'
  cqc: 'Outstanding' | 'Good' | 'Requires Improvement'
  priceFrom: number
  nextSlot: string          // "Today" | "Tomorrow" | "Mon 19 May"
  nextSlotDays: number      // days until next slot, for sorting
  reportHours: number
  scans: string[]           // ['MRI', 'CT', 'Ultrasound', 'X-Ray', 'Baby']
  tags: string[]
  featured: boolean
  lat: number
  lng: number
}

// ─── MOCK DATA ────────────────────────────────────────────────────────────────
// TODO Enes: replace with DB fetch

const MOCK_CLINICS: Clinic[] = [
  {
    id: 'medicana-winchester', slug: 'medicana-winchester',
    name: 'Medicana Winchester', city: 'Winchester', region: 'South East',
    address: 'Winchester Clinic, Hampshire', postcode: 'SO23 9LQ',
    distanceMiles: 4.2, rating: 4.9, reviewCount: 312,
    tesla: '3T', cqc: 'Outstanding', priceFrom: 275, nextSlot: 'Tomorrow', nextSlotDays: 1,
    reportHours: 24, scans: ['MRI', 'CT', 'Ultrasound', 'X-Ray', 'Baby'],
    tags: ['Free parking', '24h report', 'Baby scan suite'], featured: true,
    lat: 51.063, lng: -1.308,
  },
  {
    id: 'unirad-london', slug: 'unirad-london',
    name: 'Unirad Imaging', city: 'London', region: 'London',
    address: '14 Wimpole Street', postcode: 'W1G 9SU',
    distanceMiles: 1.1, rating: 4.7, reviewCount: 189,
    tesla: '1.5T', cqc: 'Good', priceFrom: 195, nextSlot: 'Today', nextSlotDays: 0,
    reportHours: 48, scans: ['MRI'],
    tags: ['MRI specialist', 'Step-free', 'Near tube'], featured: false,
    lat: 51.519, lng: -0.148,
  },
  {
    id: 'harley-street-imaging', slug: 'harley-street-imaging',
    name: 'Harley Street Imaging', city: 'London', region: 'London',
    address: '22 Harley Street', postcode: 'W1G 9PL',
    distanceMiles: 0.8, rating: 4.9, reviewCount: 421,
    tesla: '3T', cqc: 'Outstanding', priceFrom: 299, nextSlot: 'Tomorrow', nextSlotDays: 1,
    reportHours: 24, scans: ['MRI', 'CT', 'Ultrasound', 'X-Ray'],
    tags: ['3T scanner', 'Same day available', 'All insurers'], featured: true,
    lat: 51.521, lng: -0.150,
  },
  {
    id: 'city-diagnostic-ec2', slug: 'city-diagnostic-ec2',
    name: 'City Diagnostic Centre', city: 'London', region: 'London',
    address: '8 Moorgate', postcode: 'EC2R 6DA',
    distanceMiles: 2.1, rating: 4.3, reviewCount: 97,
    tesla: '1.5T', cqc: 'Good', priceFrom: 195, nextSlot: 'Mon 19 May', nextSlotDays: 5,
    reportHours: 48, scans: ['MRI', 'Ultrasound', 'X-Ray'],
    tags: ['Lowest price', 'City location'], featured: false,
    lat: 51.518, lng: -0.089,
  },
  {
    id: 'manchester-scan-centre', slug: 'manchester-scan-centre',
    name: 'Manchester Scan Centre', city: 'Manchester', region: 'North West',
    address: 'Deansgate Medical', postcode: 'M3 4LZ',
    rating: 4.8, reviewCount: 203,
    tesla: '3T', cqc: 'Outstanding', priceFrom: 250, nextSlot: 'Tomorrow', nextSlotDays: 1,
    reportHours: 24, scans: ['MRI', 'CT', 'Ultrasound', 'X-Ray', 'Baby'],
    tags: ['3T scanner', 'Free parking', '24h report'], featured: true,
    lat: 53.480, lng: -2.246,
  },
  {
    id: 'birmingham-imaging', slug: 'birmingham-imaging',
    name: 'Birmingham Imaging', city: 'Birmingham', region: 'West Midlands',
    address: 'Brindleyplace', postcode: 'B1 2JB',
    rating: 4.6, reviewCount: 134,
    tesla: '1.5T', cqc: 'Good', priceFrom: 210, nextSlot: 'Wed 21 May', nextSlotDays: 7,
    reportHours: 48, scans: ['MRI', 'CT', 'Ultrasound'],
    tags: ['City centre', 'Accessible'], featured: false,
    lat: 52.480, lng: -1.903,
  },
]

const CITIES = ['All cities', 'London', 'Manchester', 'Birmingham', 'Bristol', 'Edinburgh', 'Leeds', 'Winchester']
const SCAN_TYPES_FILTER = ['All scans', 'MRI', 'CT', 'Ultrasound', 'X-Ray', 'Baby']

// ─── HELPERS ─────────────────────────────────────────────────────────────────

function Stars({ rating }: { rating: number }) {
  return <span style={{ color: '#f59e0b', fontSize: 12, letterSpacing: 1 }}>{'★'.repeat(Math.floor(rating))}{'☆'.repeat(5 - Math.floor(rating))}</span>
}

// ─── CLINIC RESULT CARD ───────────────────────────────────────────────────────

function ClinicResultCard({ clinic }: { clinic: Clinic }) {
  const is3T = clinic.tesla === '3T'
  const isOutstanding = clinic.cqc === 'Outstanding'

  return (
    <div style={{
      background: '#fff',
      border: `1px solid ${clinic.featured ? '#b2edd8' : '#ebebeb'}`,
      borderRadius: 16,
      padding: '18px 20px',
      display: 'grid',
      gridTemplateColumns: '1fr auto',
      gap: 16,
      cursor: 'pointer',
      transition: 'all .15s',
    }}
      onMouseEnter={e => { const el = e.currentTarget; el.style.borderColor = '#00C9A7'; el.style.boxShadow = '0 4px 20px rgba(0,201,167,.08)' }}
      onMouseLeave={e => { const el = e.currentTarget; el.style.borderColor = clinic.featured ? '#b2edd8' : '#ebebeb'; el.style.boxShadow = 'none' }}
    >
      <div>
        {/* Name row */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 5, flexWrap: 'wrap' }}>
          <Link href={`/centres/${clinic.slug}`} style={{ fontSize: 15, fontWeight: 600, color: '#111', textDecoration: 'none' }}>
            {clinic.name}
          </Link>
          {clinic.featured && (
            <span style={{ fontSize: 9, padding: '2px 7px', borderRadius: 20, background: '#e6faf7', color: '#00a888', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5 }}>Top rated</span>
          )}
          <span style={{ fontSize: 9, padding: '2px 7px', borderRadius: 6, background: is3T ? '#f3e8ff' : '#f1f5f9', color: is3T ? '#7c3aed' : '#475569', fontWeight: 700, letterSpacing: 0.3, border: `1px solid ${is3T ? '#ddd6fe' : '#e2e8f0'}` }}>
            {clinic.tesla}
          </span>
        </div>

        {/* Meta */}
        <div style={{ display: 'flex', gap: 0, fontSize: 12, color: '#888', marginBottom: 10, flexWrap: 'wrap', alignItems: 'center' }}>
          {[
            clinic.distanceMiles ? `${clinic.distanceMiles} mi · ` : '',
            `${clinic.city}`,
            ` · CQC ${clinic.cqc}`,
            ` · Next: ${clinic.nextSlot}`,
            ` · ${clinic.reportHours}h report`,
          ].map((m, i) => m && <span key={i} style={{ color: m.includes('Outstanding') ? '#00a888' : m.includes('Today') || m.includes('Tomorrow') ? '#00a888' : '#888', fontWeight: m.includes('Today') ? 500 : 400 }}>{m}</span>)}
        </div>

        {/* Scan types */}
        <div style={{ display: 'flex', gap: 5, marginBottom: 10, flexWrap: 'wrap' }}>
          {clinic.scans.map(s => (
            <span key={s} style={{ fontSize: 11, padding: '2px 8px', borderRadius: 20, background: '#f8f8f8', color: '#666', border: '1px solid #ebebeb' }}>{s}</span>
          ))}
        </div>

        {/* Tags */}
        <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap' }}>
          {clinic.tags.map(t => (
            <span key={t} style={{ fontSize: 11, color: '#999' }}>✓ {t}</span>
          ))}
        </div>
      </div>

      {/* Right col */}
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', justifyContent: 'space-between', minWidth: 110 }}>
        <div style={{ textAlign: 'right', marginBottom: 8 }}>
          <Stars rating={clinic.rating} />
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, justifyContent: 'flex-end', marginTop: 2 }}>
            <span style={{ fontSize: 12, fontWeight: 600, color: '#111' }}>{clinic.rating}</span>
            <span style={{ fontSize: 11, color: '#bbb' }}>({clinic.reviewCount})</span>
          </div>
        </div>
        <div style={{ textAlign: 'right', marginBottom: 10 }}>
          <div style={{ fontFamily: "'Instrument Serif', serif", fontSize: 22, color: '#111', letterSpacing: -0.5 }}>£{clinic.priceFrom}</div>
          <div style={{ fontSize: 10, color: '#bbb' }}>from · incl. report</div>
        </div>
        <Link
          href={`/centres/${clinic.slug}`}
          style={{ fontSize: 12, padding: '8px 16px', borderRadius: 8, background: '#111', color: '#fff', textDecoration: 'none', fontWeight: 600, whiteSpace: 'nowrap', transition: 'background .15s' }}
          onMouseEnter={e => (e.currentTarget.style.background = '#00C9A7')}
          onMouseLeave={e => (e.currentTarget.style.background = '#111')}
        >
          View centre →
        </Link>
      </div>
    </div>
  )
}

// ─── MAP PLACEHOLDER ─────────────────────────────────────────────────────────
// TODO Enes: replace with Google Maps or Mapbox embed
// Recommended: Mapbox GL JS (free tier generous) or Google Maps Embed API

function MapPlaceholder({ clinics }: { clinics: Clinic[] }) {
  return (
    <div style={{ background: '#f0f0f0', borderRadius: 16, height: '100%', minHeight: 500, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', border: '1px solid #ebebeb', position: 'relative', overflow: 'hidden' }}>
      {/* Grid lines to suggest a map */}
      <div style={{ position: 'absolute', inset: 0, backgroundImage: 'linear-gradient(#e8e8e8 1px, transparent 1px), linear-gradient(90deg, #e8e8e8 1px, transparent 1px)', backgroundSize: '32px 32px', opacity: 0.5 }} />

      {/* Pin dots */}
      {clinics.slice(0, 5).map((c, i) => (
        <div key={c.id} style={{
          position: 'absolute',
          left: `${20 + i * 14}%`,
          top: `${25 + (i % 3) * 20}%`,
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3
        }}>
          <div style={{ width: 10, height: 10, borderRadius: '50%', background: c.featured ? '#00C9A7' : '#111', border: '2px solid #fff', boxShadow: '0 2px 6px rgba(0,0,0,.2)' }} />
          <div style={{ fontSize: 10, background: '#fff', padding: '2px 6px', borderRadius: 4, border: '1px solid #ebebeb', color: '#111', fontWeight: 500, whiteSpace: 'nowrap', boxShadow: '0 1px 4px rgba(0,0,0,.08)' }}>
            {c.name.split(' ')[0]}
          </div>
        </div>
      ))}

      <div style={{ position: 'relative', zIndex: 1, textAlign: 'center', padding: 24 }}>
        <div style={{ fontSize: 28, marginBottom: 8 }}>🗺️</div>
        <div style={{ fontSize: 13, color: '#888', marginBottom: 4 }}>Interactive map</div>
        <div style={{ fontSize: 11, color: '#bbb' }}>
          TODO: Google Maps or Mapbox embed
        </div>
      </div>
    </div>
  )
}

// ─── PAGE ─────────────────────────────────────────────────────────────────────

export default function FindACentrePage() {
  const [cityFilter, setCityFilter] = useState('All cities')
  const [scanFilter, setScanFilter] = useState('All scans')
  const [teslaFilter, setTeslaFilter] = useState<'any' | '1.5T' | '3T'>('any')
  const [sortBy, setSortBy] = useState<'recommended' | 'price' | 'rating' | 'distance'>('recommended')
  const [searchQuery, setSearchQuery] = useState('')

  const filtered = useMemo(() => {
    let list = [...MOCK_CLINICS]
    if (cityFilter !== 'All cities') list = list.filter(c => c.city === cityFilter)
    if (scanFilter !== 'All scans') list = list.filter(c => c.scans.includes(scanFilter))
    if (teslaFilter !== 'any') list = list.filter(c => c.tesla === teslaFilter)
    if (searchQuery) {
      const q = searchQuery.toLowerCase()
      list = list.filter(c => c.name.toLowerCase().includes(q) || c.city.toLowerCase().includes(q) || c.postcode.toLowerCase().includes(q))
    }
    if (sortBy === 'price') list.sort((a, b) => a.priceFrom - b.priceFrom)
    else if (sortBy === 'rating') list.sort((a, b) => b.rating - a.rating)
    else if (sortBy === 'distance') list.sort((a, b) => (a.distanceMiles ?? 99) - (b.distanceMiles ?? 99))
    else list.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0) || b.rating - a.rating)
    return list
  }, [cityFilter, scanFilter, teslaFilter, sortBy, searchQuery])

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'DM Sans', sans-serif; background: #fff; color: #222; -webkit-font-smoothing: antialiased; }
      `}</style>

      <Header />
      <Breadcrumb items={[{ label: 'Home', href: '/' }, { label: 'Find a Centre' }]} />

      {/* PAGE HEADER */}
      <div style={{ maxWidth: 1180, margin: '0 auto', padding: '48px 48px 32px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', flexWrap: 'wrap', gap: 20 }}>
          <div>
            <div style={{ fontSize: 10, letterSpacing: 3, color: '#bbb', fontWeight: 500, marginBottom: 12, textTransform: 'uppercase' }}>600+ centres</div>
            <h1 style={{ fontFamily: "'Instrument Serif', serif", fontSize: 42, lineHeight: 1.1, letterSpacing: -1.4, color: '#111' }}>
              Find a centre<br /><em style={{ fontStyle: 'italic', color: '#00C9A7' }}>near you.</em>
            </h1>
          </div>

          {/* Search input */}
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <input
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search by name, city or postcode…"
              style={{ padding: '10px 14px', border: '1.5px solid #ebebeb', borderRadius: 9, fontSize: 13, fontFamily: 'inherit', color: '#111', outline: 'none', width: 280 }}
              onFocus={e => (e.currentTarget.style.borderColor = '#00C9A7')}
              onBlur={e => (e.currentTarget.style.borderColor = '#ebebeb')}
            />
            <button style={{ padding: '10px 18px', background: '#111', color: '#fff', border: 'none', borderRadius: 9, fontSize: 13, fontWeight: 500, cursor: 'pointer', fontFamily: 'inherit' }}>
              Search
            </button>
          </div>
        </div>
      </div>

      {/* FILTER BAR */}
      <div style={{ borderTop: '1px solid #ebebeb', borderBottom: '1px solid #ebebeb', background: '#fafafa' }}>
        <div style={{ maxWidth: 1180, margin: '0 auto', padding: '0 48px', display: 'flex', gap: 0, alignItems: 'center', flexWrap: 'wrap' }}>

          {/* City */}
          <div style={{ padding: '14px 20px 14px 0', borderRight: '1px solid #ebebeb', display: 'flex', flexDirection: 'column', gap: 4 }}>
            <div style={{ fontSize: 9, fontWeight: 700, color: '#bbb', letterSpacing: 1.5, textTransform: 'uppercase' }}>City</div>
            <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap' }}>
              {CITIES.slice(0, 5).map(city => (
                <button key={city} onClick={() => setCityFilter(city)} style={{ fontSize: 12, padding: '4px 10px', borderRadius: 20, border: `1.5px solid ${cityFilter === city ? '#111' : '#ebebeb'}`, background: cityFilter === city ? '#111' : '#fff', color: cityFilter === city ? '#fff' : '#666', cursor: 'pointer', fontFamily: 'inherit', transition: 'all .15s' }}>
                  {city}
                </button>
              ))}
            </div>
          </div>

          {/* Scan type */}
          <div style={{ padding: '14px 20px', borderRight: '1px solid #ebebeb', display: 'flex', flexDirection: 'column', gap: 4 }}>
            <div style={{ fontSize: 9, fontWeight: 700, color: '#bbb', letterSpacing: 1.5, textTransform: 'uppercase' }}>Scan type</div>
            <div style={{ display: 'flex', gap: 5 }}>
              {SCAN_TYPES_FILTER.map(s => (
                <button key={s} onClick={() => setScanFilter(s)} style={{ fontSize: 12, padding: '4px 10px', borderRadius: 20, border: `1.5px solid ${scanFilter === s ? '#111' : '#ebebeb'}`, background: scanFilter === s ? '#111' : '#fff', color: scanFilter === s ? '#fff' : '#666', cursor: 'pointer', fontFamily: 'inherit', transition: 'all .15s' }}>
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* Tesla — only relevant for MRI */}
          {(scanFilter === 'All scans' || scanFilter === 'MRI') && (
            <div style={{ padding: '14px 20px', borderRight: '1px solid #ebebeb', display: 'flex', flexDirection: 'column', gap: 4 }}>
              <div style={{ fontSize: 9, fontWeight: 700, color: '#bbb', letterSpacing: 1.5, textTransform: 'uppercase' }}>Scanner quality</div>
              <div style={{ display: 'flex', gap: 5 }}>
                {([['any', 'Any'], ['1.5T', '1.5T'], ['3T', '3T ★']] as const).map(([val, label]) => (
                  <button key={val} onClick={() => setTeslaFilter(val)} style={{ fontSize: 12, padding: '4px 10px', borderRadius: 20, border: `1.5px solid ${teslaFilter === val ? (val === '3T' ? '#7c3aed' : '#111') : '#ebebeb'}`, background: teslaFilter === val ? (val === '3T' ? '#7c3aed' : '#111') : '#fff', color: teslaFilter === val ? '#fff' : '#666', cursor: 'pointer', fontFamily: 'inherit', transition: 'all .15s' }}>
                    {label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Sort */}
          <div style={{ padding: '14px 20px', marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 12, color: '#bbb' }}>Sort:</span>
            {([['recommended', 'Recommended'], ['price', 'Price ↑'], ['rating', 'Rating'], ['distance', 'Distance']] as const).map(([val, label]) => (
              <button key={val} onClick={() => setSortBy(val)} style={{ fontSize: 12, padding: '4px 10px', borderRadius: 20, border: `1.5px solid ${sortBy === val ? '#111' : '#ebebeb'}`, background: sortBy === val ? '#111' : '#fff', color: sortBy === val ? '#fff' : '#666', cursor: 'pointer', fontFamily: 'inherit', transition: 'all .15s' }}>
                {label}
              </button>
            ))}
          </div>

        </div>
      </div>

      {/* MAIN — split map + results */}
      <div style={{ maxWidth: 1180, margin: '0 auto', padding: '28px 48px 64px', display: 'grid', gridTemplateColumns: '1fr 420px', gap: 24, alignItems: 'start' }}>

        {/* LEFT — results */}
        <div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
            <span style={{ fontSize: 13, color: '#888' }}>
              <span style={{ color: '#111', fontWeight: 600 }}>{filtered.length}</span> centre{filtered.length !== 1 ? 's' : ''} found
              {cityFilter !== 'All cities' ? ` in ${cityFilter}` : ''}
              {scanFilter !== 'All scans' ? ` · ${scanFilter}` : ''}
            </span>
            {teslaFilter !== 'any' && (
              <span style={{ fontSize: 11, padding: '3px 10px', borderRadius: 20, background: teslaFilter === '3T' ? '#f3e8ff' : '#f1f5f9', color: teslaFilter === '3T' ? '#7c3aed' : '#475569', fontWeight: 600 }}>
                Showing {teslaFilter} centres only
              </span>
            )}
          </div>

          {filtered.length === 0 ? (
            <div style={{ padding: '48px 24px', textAlign: 'center', border: '1px dashed #ebebeb', borderRadius: 16 }}>
              <div style={{ fontSize: 28, marginBottom: 12 }}>🔍</div>
              <div style={{ fontSize: 14, fontWeight: 500, color: '#111', marginBottom: 6 }}>No centres found</div>
              <div style={{ fontSize: 13, color: '#888' }}>Try adjusting your filters or searching a different city.</div>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {filtered.map(clinic => <ClinicResultCard key={clinic.id} clinic={clinic} />)}
            </div>
          )}

          {/* City quick-links */}
          <div style={{ marginTop: 36, padding: '24px', background: '#f8f8f8', borderRadius: 16, border: '1px solid #ebebeb' }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: '#111', marginBottom: 12 }}>Browse by city</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 7 }}>
              {[
                { city: 'London', count: '240+', href: '/centres/london' },
                { city: 'Manchester', count: '45+', href: '/centres/manchester' },
                { city: 'Birmingham', count: '38+', href: '/centres/birmingham' },
                { city: 'Bristol', count: '22+', href: '/centres/bristol' },
                { city: 'Leeds', count: '30+', href: '/centres/leeds' },
                { city: 'Edinburgh', count: '18+', href: '/centres/edinburgh' },
                { city: 'Glasgow', count: '20+', href: '/centres/glasgow' },
                { city: 'Cardiff', count: '14+', href: '/centres/cardiff' },
              ].map(c => (
                <Link key={c.city} href={c.href} style={{ padding: '10px 12px', border: '1px solid #ebebeb', borderRadius: 10, background: '#fff', textDecoration: 'none', display: 'flex', justifyContent: 'space-between', alignItems: 'center', transition: 'all .15s' }}
                  onMouseEnter={e => { const el = e.currentTarget; el.style.borderColor = '#00C9A7'; el.style.color = '#00a888' }}
                  onMouseLeave={e => { const el = e.currentTarget; el.style.borderColor = '#ebebeb' }}
                >
                  <span style={{ fontSize: 12, fontWeight: 500, color: '#111' }}>{c.city}</span>
                  <span style={{ fontSize: 11, color: '#bbb' }}>{c.count}</span>
                </Link>
              ))}
            </div>
          </div>
        </div>

        {/* RIGHT — sticky map */}
        <div style={{ position: 'sticky', top: 76 }}>
          <MapPlaceholder clinics={filtered} />

          {/* Under map: Tesla info */}
          <div style={{ marginTop: 14, padding: '14px 16px', background: '#f8f8f8', borderRadius: 12, border: '1px solid #ebebeb' }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: '#111', marginBottom: 6, display: 'flex', gap: 8, alignItems: 'center' }}>
              <span style={{ fontSize: 10, padding: '2px 7px', borderRadius: 4, background: '#f3e8ff', color: '#7c3aed', fontWeight: 700 }}>3T</span>
              vs
              <span style={{ fontSize: 10, padding: '2px 7px', borderRadius: 4, background: '#f1f5f9', color: '#475569', fontWeight: 700 }}>1.5T</span>
              Which scanner do I need?
            </div>
            <p style={{ fontSize: 12, color: '#888', lineHeight: 1.6, margin: 0 }}>
              For most routine scans — knee, shoulder, spine, abdomen — a 1.5T scanner produces excellent results at lower cost. 3T is recommended for brain, cardiac, and oncology imaging.{' '}
              <Link href="/services/mri-scan#tesla" style={{ color: '#00a888', textDecoration: 'none' }}>Learn more →</Link>
            </p>
          </div>
        </div>

      </div>

      {/* FOR CLINICS STRIP */}
      <div style={{ background: '#111', padding: '40px 48px' }}>
        <div style={{ maxWidth: 1180, margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 20 }}>
          <div>
            <div style={{ fontSize: 14, fontWeight: 600, color: '#fff', marginBottom: 4 }}>Are you a clinic or imaging centre?</div>
            <div style={{ fontSize: 13, color: 'rgba(255,255,255,.45)' }}>Join the ScanBook partner network. Reach thousands of patients searching for private scans near you.</div>
          </div>
          <Link href="/partners" style={{ padding: '12px 22px', border: '1px solid rgba(255,255,255,.2)', borderRadius: 9, color: '#fff', textDecoration: 'none', fontSize: 13, fontWeight: 500, whiteSpace: 'nowrap', transition: 'all .15s' }}
            onMouseEnter={e => { e.currentTarget.style.background = '#00C9A7'; e.currentTarget.style.borderColor = '#00C9A7' }}
            onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.borderColor = 'rgba(255,255,255,.2)' }}
          >
            List your centre →
          </Link>
        </div>
      </div>

      <Footer />
    </>
  )
}
